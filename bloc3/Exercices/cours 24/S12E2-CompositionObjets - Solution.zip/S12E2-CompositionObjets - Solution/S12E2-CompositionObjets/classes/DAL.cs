﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12E2_CompositionObjets.classes
{
    public static class DAL
    {
        public const string APPSETTINGS_FILE = "appsettings.json";
        public const string CONNECTION_STRING_NAME = "DefaultConnection";

       

        // Lire le appsettings.json
        private static readonly  IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile(APPSETTINGS_FILE, optional: false, reloadOnChange: true)
            .Build();

    

        // ---------------------------------------------------------
        //  MÉTHODE POUR CRÉER UNE CONNEXION
        // ---------------------------------------------------------
        private static MySqlConnection CreerConnexion()
        {
            return new MySqlConnection(config.GetConnectionString(CONNECTION_STRING_NAME));
        }

        // ---------------------------------------------------------
        //  MÉTHODE POUR FERMER UNE CONNEXION
        // ---------------------------------------------------------
        private static void FermerConnexion(MySqlConnection con)
        {
            if (con != null && con.State != System.Data.ConnectionState.Closed)
            {
                con.Close();
            }
        }

        public static List<Auteur> GetTousLesAuteurs()
        {
            List<Auteur> auteurs = new List<Auteur>();
            MySqlConnection con = null;

            try
            {
                con = CreerConnexion();
                con.Open();

                string sql = "SELECT id, nom FROM auteur ORDER BY nom";

                using (MySqlCommand cmd = new MySqlCommand(sql, con))
                using (MySqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        auteurs.Add(new Auteur(dr.GetInt32("id"),dr.GetString("nom")));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur dans GetTousLesAuteurs : " + ex.Message, ex);
            }
            finally
            {
                FermerConnexion(con);
            }

            return auteurs;
        }



        // ---------------------------------------------------------
        //  OBTENIR LISTE DES LIVRES (sans auteurs)
        // ---------------------------------------------------------
        public static List<Livre> GetLivres()
        {
            List<Livre> livres = new List<Livre>();
            MySqlConnection con = null;

            try
            {
                con = CreerConnexion();
                con.Open();

                string sql = "SELECT id, titre, annee FROM livre ORDER BY titre";

                using (MySqlCommand cmd = new MySqlCommand(sql, con))

                using (MySqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        livres.Add(new Livre(dr.GetInt32(0), dr.GetString(1), dr.GetUInt16(2)));
                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur dans GetLivres : " + ex.Message, ex);
            }
            finally
            {
                FermerConnexion(con);
            }

            return livres;
        }


        // ---------------------------------------------------------
        //  OBTENIR UN LIVRE ET SES AUTEURS
        // ---------------------------------------------------------
        public static Livre GetLivreAvecAuteurs(int idLivre)
        {
            Livre livre = null;
            MySqlConnection con = null;

            try
            {
                con = CreerConnexion();
                con.Open();

                string sql = @"
            SELECT 
                l.id,
                l.titre,
                l.annee,
                a.id,
                a.nom
            FROM livre l
            LEFT JOIN livre_auteur la ON la.id_livre = l.id
            LEFT JOIN auteur a ON a.id = la.id_auteur
            WHERE l.id = @id;";

                using (MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@id", idLivre);

                    using (MySqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            // Créer l'objet livre une seule fois
                            if (livre == null)
                            {
                                livre = new Livre(dr.GetInt32(0), dr.GetString(1), dr.GetUInt16(2));
                                
                            }

                          
                                livre.Auteurs.Add(new Auteur(dr.GetInt32(3), dr.GetString(4)));
                            
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur dans GetLivreAvecAuteurs : " + ex.Message, ex);
            }
            finally
            {
                FermerConnexion(con);
            }

            return livre;
        }


        // ---------------------------------------------------------
        //  AJOUTER UN LIVRE + SES AUTEURS
        // ---------------------------------------------------------
        public static void AjouterLivre(Livre livre)
        {
            MySqlConnection con = null;

            try
            {
                con = CreerConnexion();
                con.Open();


                try
                {
                    // Insérer le livre
                    string requete = @"
                    INSERT INTO livre (titre, annee)
                    VALUES (@titre, @annee);";



                    MySqlCommand cmd = new MySqlCommand(requete, con);

                    
                    cmd.Parameters.AddWithValue("@titre", livre.Titre);
                    cmd.Parameters.AddWithValue("@annee", livre.Annee);
                    cmd.ExecuteNonQuery();
                    livre.Id = (int) cmd.LastInsertedId;

                    // Associer les auteurs
                    requete = @"INSERT INTO livre_auteur (id_livre, id_auteur)
                                    VALUES (@idLivre, @idAuteur)";

                    cmd.CommandText = requete;
                    cmd.Parameters.Clear();
                    
                  
                    cmd.Parameters.AddWithValue("@idLivre", livre.Id);
                    cmd.Parameters.Add("@idAuteur", MySqlDbType.Int32);

                    cmd.Prepare();

                    foreach (Auteur a in livre.Auteurs)
                    {

                               
                        cmd.Parameters["@idAuteur"].Value =  a.Id;
                        cmd.ExecuteNonQuery();
                    }
                    
                }
                catch
                {
                   
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur dans AjouterLivre : " + ex.Message, ex);
            }
            finally
            {
                FermerConnexion(con);
            }
        }
    }
}
