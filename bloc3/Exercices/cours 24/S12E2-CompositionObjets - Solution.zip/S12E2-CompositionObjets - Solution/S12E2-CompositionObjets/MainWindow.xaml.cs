﻿using S12E2_CompositionObjets.classes;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12E2_CompositionObjets
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AfficherListeLivres();
            AfficherAuteurs();
        }

        private void AfficherListeLivres()
        {
            lstLivres.ItemsSource = null;
            lstLivres.ItemsSource = DAL.GetLivres();

        }

        private void AfficherAuteurs()
        {
            cboAuteurs.ItemsSource = null;
            cboAuteurs.ItemsSource = DAL.GetTousLesAuteurs();
        }

        private void btnAjouterAuteur_Click(object sender, RoutedEventArgs e)
        {
            if(cboAuteurs.SelectedItem != null)
            {
                if(!lstAuteursLivre.Items.Contains(cboAuteurs.SelectedItem))
                    lstAuteursLivre.Items.Add(cboAuteurs.SelectedItem);

                cboAuteurs.SelectedIndex = -1;
            }
        }

        private void btnEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            

           
            Livre livre = new Livre(0, txtTitre.Text, ushort.Parse(txtAnnee.Text));

            foreach (Auteur auteur in lstAuteursLivre.Items)
            {
                livre.Auteurs.Add(auteur);
            }

            DAL.AjouterLivre(livre);
            AfficherListeLivres();

            MessageBox.Show("Le livre a été ajouté avec succès!");






        }

        private void EffacerFormulaire()
        {
            txtTitre.Clear();
            txtAnnee.Clear();
            lstAuteursLivre.ItemsSource = null;
            cboAuteurs.SelectedIndex = -1;
            lstLivres.SelectedIndex = -1;
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            EffacerFormulaire();
        }

        private void lstLivres_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(lstLivres.SelectedItem is not null)
            {
                Livre livre = lstLivres.SelectedItem as Livre;

                livre = DAL.GetLivreAvecAuteurs(livre.Id);

                txtTitre.Text = livre.Titre;
                txtAnnee.Text = livre.Annee.ToString();

                lstAuteursLivre.ItemsSource = livre.Auteurs;
            }
        }
    }
}