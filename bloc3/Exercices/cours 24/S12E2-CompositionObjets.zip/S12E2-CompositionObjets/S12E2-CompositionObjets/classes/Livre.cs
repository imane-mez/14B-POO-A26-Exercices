﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12E2_CompositionObjets.classes
{
    public  class Livre
    {

        public int Id { get; set; }
        public string Titre { get; set; }
        public ushort Annee { get; set; }

        public List<Auteur> Auteurs { get; set; } 

        public Livre(int id, string titre, ushort annee)
        {
            Id = id;
            Titre = titre;
            Annee = annee;

            Auteurs = new List<Auteur>();
        }

        public override string ToString()
        {
            return $"{Titre} - {Annee}";
        }
    }
}
