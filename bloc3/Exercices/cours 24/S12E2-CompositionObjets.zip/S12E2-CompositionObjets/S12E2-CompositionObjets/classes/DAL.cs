﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12E2_CompositionObjets.classes
{
    public static class DAL
    {
        public const string APPSETTINGS_FILE = "appsettings.json";
        public const string CONNECTION_STRING_NAME = "DefaultConnection";

       

        // Lire le appsettings.json
        private static readonly  IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile(APPSETTINGS_FILE, optional: false, reloadOnChange: true)
            .Build();

    

        // ---------------------------------------------------------
        //  MÉTHODE POUR CRÉER UNE CONNEXION
        // ---------------------------------------------------------
        private static MySqlConnection CreerConnexion()
        {
            return new MySqlConnection(config.GetConnectionString(CONNECTION_STRING_NAME));
        }

        // ---------------------------------------------------------
        //  MÉTHODE POUR FERMER UNE CONNEXION
        // ---------------------------------------------------------
        private static void FermerConnexion(MySqlConnection con)
        {
            if (con != null && con.State != System.Data.ConnectionState.Closed)
            {
                con.Close();
            }
        }

        /// <summary>
        /// Permet d'obtenir la liste des auteurs
        /// </summary>
        /// <returns>Liste des auteurs</returns>

        public static List<Auteur> GetTousLesAuteurs()
        {
            throw new NotImplementedException();
        }



       /// <summary>
       /// Permet d'obtenir la liste des livres sans les auteurs
       /// </summary>
       /// <returns>Liste de livres sans les auteurs</returns>

        public static List<Livre> GetLivres()
        {

            throw new NotImplementedException();
        }


       /// <summary>
       /// Permet d'obtenir un livre et ses auteurs
       /// </summary>
       /// <param name="idLivre">Identifiant du livre</param>
       /// <returns>Livre avec ses auteurs</returns>
        public static Livre GetLivreAvecAuteurs(int idLivre)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Permet d'ajouter un livre avec ses auteurs
        /// </summary>
        /// <param name="livre">Livre à ajouter</param>
        public static void AjouterLivre(Livre livre)
        {
            throw new NotImplementedException();
        }
    }
}
