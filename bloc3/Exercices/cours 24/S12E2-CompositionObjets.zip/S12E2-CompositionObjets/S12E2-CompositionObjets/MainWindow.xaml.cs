﻿using S12E2_CompositionObjets.classes;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12E2_CompositionObjets
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AfficherListeLivres();
            AfficherAuteurs();
        }

        private void AfficherListeLivres()
        {
            

        }

        private void AfficherAuteurs()
        {
           
        }

        private void btnAjouterAuteur_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            

        }

        /// <summary>
        /// Efface le contenu du formulaire
        /// </summary>
        private void EffacerFormulaire()
        {
            txtTitre.Clear();
            txtAnnee.Clear();
            lstAuteursLivre.ItemsSource = null;
            cboAuteurs.SelectedIndex = -1;
            lstLivres.SelectedIndex = -1;
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            EffacerFormulaire();
        }

        private void lstLivres_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}