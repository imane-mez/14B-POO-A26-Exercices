﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace S12E2_CompositionObjets
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
