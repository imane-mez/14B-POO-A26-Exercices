﻿CREATE DATABASE IF NOT EXISTS bibliotheque CHARACTER SET utf8mb4;
USE bibliotheque;

CREATE TABLE auteur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL
);

CREATE TABLE livre (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titre VARCHAR(200) NOT NULL,
    annee INT NOT NULL
);

CREATE TABLE livre_auteur (
    id_livre INT NOT NULL,
    id_auteur INT NOT NULL,
    PRIMARY KEY(id_livre, id_auteur),
    FOREIGN KEY(id_livre) REFERENCES livre(id) ON DELETE CASCADE,
    FOREIGN KEY(id_auteur) REFERENCES auteur(id) ON DELETE CASCADE
);

-- ========================
-- INSERTION DES AUTEURS
-- ========================
INSERT INTO auteur (nom) VALUES
('Victor Hugo'),            -- 1
('Guy de Maupassant'),      -- 2
('Émile Zola'),             -- 3
('Mary Shelley'),           -- 4
('Arthur Conan Doyle');     -- 5

-- ========================
-- INSERTION DES LIVRES
-- ========================
INSERT INTO livre (titre, annee) VALUES
('Les Misérables', 1862),                   -- 1
('Notre-Dame de Paris', 1831),              -- 2
('Le Horla', 1887),                          -- 3
('Germinal', 1885),                          -- 4
('Frankenstein', 1818),                      -- 5
('Sherlock Holmes : Une étude en rouge', 1887); -- 6

-- ========================
-- ASSOCIATION LIVRE ↔ AUTEUR
-- ========================

-- Victor Hugo
INSERT INTO livre_auteur (id_livre, id_auteur) VALUES
(1, 1),   -- Les Misérables → Victor Hugo
(2, 1);   -- Notre-Dame de Paris → Victor Hugo

-- Guy de Maupassant
INSERT INTO livre_auteur (id_livre, id_auteur) VALUES
(3, 2);   -- Le Horla → Maupassant

-- Émile Zola
INSERT INTO livre_auteur (id_livre, id_auteur) VALUES
(4, 3);   -- Germinal → Zola

-- Mary Shelley
INSERT INTO livre_auteur (id_livre, id_auteur) VALUES
(5, 4);   -- Frankenstein → Mary Shelley

-- Arthur Conan Doyle
INSERT INTO livre_auteur (id_livre, id_auteur) VALUES
(6, 5);   -- Sherlock Holmes → Conan Doyle
