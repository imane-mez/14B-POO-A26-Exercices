﻿namespace S12E1_BD.enums
{
    public enum Genre
    {
        Roman,
        ScienceFiction,
        Biographie,
        Histoire,
        Fantaisie,
        Education
    }
}
