﻿using S12E1_BD.enums;

namespace S12E1_BD.classes
{
    public class Livre
    {
        private uint _id;
        private string _titre;
        private string _auteur;
        private ushort _anneePublication;
        private Genre _genre;



        public uint Id
        {
            get { return _id; }
            set { _id = value; }
        }


        public string Titre
        {
            get { return _titre; }
            set { _titre = value; }
        }

        public string Auteur
        {
            get { return _auteur; }
            set { _auteur = value; }
        }

        public ushort AnneePublication
        {
            get { return _anneePublication; }
            set { _anneePublication = value; }
        }

        public Genre Genre
        {
            get { return _genre; }
            set { _genre = value; }
        }

        public Livre(uint id, string titre, string auteur, ushort anneePublication, Genre genre)
        {
            Id = id;
            Titre = titre;
            Auteur = auteur;
            AnneePublication = anneePublication;
            Genre = genre;
        }

        public override string ToString()
        {
            return $"{Titre} - {AnneePublication} par {Auteur} ({Genre})";
        }
    }


}
