﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using S12E1_BD.enums;

namespace S12E1_BD.classes
{

    public static class DAL
    {
        private const string APPSETTINGS_FILE = "appsettings.json";
        private const string CONNECTION_STRING_NAME = "DefaultConnection";

        private static readonly IConfiguration _config = new ConfigurationBuilder()
                .AddJsonFile(APPSETTINGS_FILE, optional: false, reloadOnChange: true)
                .Build();

        private static MySqlConnection CreerConnection()
        {
         
            string connectionString = _config.GetConnectionString(CONNECTION_STRING_NAME);

            return new MySqlConnection(connectionString);
        }

        private static void FermerConnection(MySqlConnection cn)
        {
            if (cn != null && cn.State == System.Data.ConnectionState.Open)
            {
                cn.Close();
                cn.Dispose();
            }
        }

       
        public static List<Livre> ObtenirListeLivres()
        {
            MySqlConnection cn = null;
            List<Livre> lstLivres = new List<Livre>();

            try
            {
                cn = CreerConnection();
                cn.Open();

                string requete =
                    @"SELECT Id, Titre, Auteur, AnneePublication, Genre
                      FROM Livres
                      ORDER BY Titre, Auteur;";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                MySqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Livre l = new Livre(
                        dr.GetUInt32(0),
                        dr.GetString(1),
                        dr.GetString(2),
                        dr.GetUInt16(3),
                        (Genre) dr.GetByte(4)
                    );

                    lstLivres.Add(l);
                }

                dr.Close();
                dr.DisposeAsync();

            }
            catch (Exception ex)
            {
                throw new Exception("Une erreur s'est produite lors de l'obtention livre", ex); // très important : on relance
            }
            finally
            {
                FermerConnection(cn);
            }

            return lstLivres;
        }

        public static void Ajouter(Livre pLivre)
        {
            if (pLivre == null)
                throw new ArgumentNullException(nameof(pLivre), "Le livre ne doit pas être null.");

            MySqlConnection cn = null;

            try
            {
                cn = CreerConnection(); 
                cn.Open();

                string requete =
                    @"INSERT INTO Livres (Titre, Auteur, AnneePublication, Genre)
                      VALUES (@titre, @auteur, @annee, @genre);";

                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@titre", pLivre.Titre);
                cmd.Parameters.AddWithValue("@auteur", pLivre.Auteur);
                cmd.Parameters.AddWithValue("@annee", pLivre.AnneePublication);
                cmd.Parameters.AddWithValue("@genre", pLivre.Genre);

                cmd.ExecuteNonQuery();

                pLivre.Id = (uint)cmd.LastInsertedId;

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                FermerConnection(cn);
            }
        }

        public static void Modifier(Livre pLivre)
        {
            if (pLivre == null)
                throw new ArgumentNullException(nameof(pLivre), "Le livre ne doit pas être null.");

            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete =
                    @"UPDATE Livres SET
                        Titre = @titre,
                        Auteur = @auteur,
                        AnneePublication = @annee,
                        Genre = @genre
                      WHERE Id = @id;";

                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@id", pLivre.Id);
                cmd.Parameters.AddWithValue("@titre", pLivre.Titre);
                cmd.Parameters.AddWithValue("@auteur", pLivre.Auteur);
                cmd.Parameters.AddWithValue("@annee", pLivre.AnneePublication);
                cmd.Parameters.AddWithValue("@genre", pLivre.Genre);

                int nbLignes =  cmd.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                FermerConnection(cn);
            }
        }

       
        public static void Supprimer(uint pId)
        {
            if (pId < 1)
                throw new ArgumentOutOfRangeException(nameof(pId), "L'identifiant doit être supérieur à 0.");

            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = @"DELETE FROM Livres WHERE Id = @id;";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                cmd.Parameters.AddWithValue("@id", pId);

                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                FermerConnection(cn);
            }
        }
    }
}
