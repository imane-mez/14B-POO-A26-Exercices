﻿using S12E1_BD.classes;
using S12E1_BD.enums;

internal class Program
{
    private static void Main(string[] args)
    {
        //todo: Écrire le code permettant de tester les opérations sur la base de données
        try
        {
            Console.WriteLine("=== Test DAL - Livres ===");

            // 1. Afficher la liste des livres
            Console.WriteLine("\n--- Liste des livres ---");
            AfficherLivres();

            // 2. Ajouter un livre
            Console.WriteLine("\n--- Ajout d'un livre ---");
            Livre nouveauLivre = new Livre(0, "Nouveau livre", "Auteur Test", 2024, Genre.Biographie);
            DAL.Ajouter(nouveauLivre);
            Console.WriteLine("Livre ajouté.");

            // Liste après ajout
            AfficherLivres();

            // 3. Modifier un livre
            Console.WriteLine("\n--- Modification d'un livre ---");
            nouveauLivre.Titre = "Titre modifié";
            DAL.Modifier(nouveauLivre);
            Console.WriteLine("Livre modifié.");

            // Liste après modification
            AfficherLivres();

            // 4. Supprimer un livre
            Console.WriteLine("\n--- Suppression d'un livre ---");
            DAL.Supprimer(nouveauLivre.Id);
            Console.WriteLine($"Livre #{nouveauLivre.Id} supprimé.");

            // Liste finale
            AfficherLivres();
        }
        catch (Exception ex)
        {
            Console.WriteLine("\n ERREUR : " + ex.Message);
        }

        Console.WriteLine("\nAppuyez sur une touche pour quitter...");
        Console.ReadKey();
    }
    

    private static void AfficherLivres()
    {
        List<Livre> livres = DAL.ObtenirListeLivres();

        foreach (var l in livres)
        {
            Console.WriteLine($"{l.Id} : {l.Titre} - {l.Auteur} ({l.AnneePublication}) Genre={l.Genre}");
        }
    }
}


