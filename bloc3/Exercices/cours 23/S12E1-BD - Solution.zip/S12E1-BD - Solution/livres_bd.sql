-- --------------------------------------------------------
-- Base de données : livres_bd
-- --------------------------------------------------------
use livres_bd;

-- Supprime la table si elle existe
DROP TABLE IF EXISTS `livres`;

-- Crée la table livres
CREATE TABLE `livres` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Titre` VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  `Auteur` VARCHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  `AnneePublication` SMALLINT UNSIGNED NOT NULL,
  `Genre` TINYINT NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_general_ci;
