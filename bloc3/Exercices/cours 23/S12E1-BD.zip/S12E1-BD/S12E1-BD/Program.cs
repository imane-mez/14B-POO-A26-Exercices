﻿using S12E1_BD.classes;
using S12E1_BD.enums;

internal class Program
{
    private static void Main(string[] args)
    {
        //todo: Écrire le code permettant de tester les opérations sur la base de données

    }


}