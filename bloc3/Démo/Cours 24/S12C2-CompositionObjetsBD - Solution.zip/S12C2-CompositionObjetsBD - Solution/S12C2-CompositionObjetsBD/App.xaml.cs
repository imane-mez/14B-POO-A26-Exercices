﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace S12C2_CompositionObjetsBD
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
