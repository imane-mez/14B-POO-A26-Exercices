﻿using S12C2_CompositionObjetsBD.classes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12C2_CompositionObjetsBD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ChargerActeurs();
            ChargerFilms();

        }

        private void ChargerActeurs()
        {
            cboActeurs.ItemsSource = DAL.ObtenirActeurs();
        }

        private void ChargerFilms()
        {
            lstFilms.ItemsSource = DAL.ObtenirFilms();
        }

        private void btnAjouterActeur_Click(object sender, RoutedEventArgs e)
        {
            if(cboActeurs.SelectedIndex != -1)
            {
                if (!lstActeurs.Items.Contains(cboActeurs.SelectedItem))
                    lstActeurs.Items.Add(cboActeurs.SelectedItem);

            }
        }

        private void btnAjouterFilm_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Validation du titre
                if (string.IsNullOrWhiteSpace(txtTitre.Text))
                {
                    MessageBox.Show("Vous devez entrer un titre.");
                    return;
                }

                // Validation de l'année
                int annee;
                if (!int.TryParse(txtAnnee.Text, out annee))
                {
                    MessageBox.Show("Année invalide.");
                    return;
                }

                // Création du film
                Film film = new Film(0, txtTitre.Text, annee);

                // Ajouter les acteurs sélectionnés (ListBox de droite)
                foreach (Acteur acteur in lstActeurs.Items)
                {
                    film.AjouterActeur(acteur);
                }

                // Enregistrement BD
                DAL.AjouterFilm(film);
               

                MessageBox.Show("Film ajouté avec succès!");

                // Actualiser la liste des films
                ChargerFilms();

                EffacerFormulaire();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            EffacerFormulaire();
        }

        private void EffacerFormulaire()
        {
            txtTitre.Clear();
            txtAnnee.Clear();
            lstActeurs.Items.Clear();
            cboActeurs.SelectedIndex = -1;
            lstFilms.SelectedIndex = -1;
        }

        private void lstFilms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(lstFilms.SelectedIndex != -1)
            {
                Film film = (Film)lstFilms.SelectedItem;

                // aller chercher ce film dans la BD au cas où il aurait changé ...
                // on ne le fait pas ici car l'application ne propose pas de modification/suppression de films

                txtTitre.Text = film.Titre;
                txtAnnee.Text = film.Annee.ToString();

                lstActeurs.Items.Clear();

                foreach (Acteur acteur in film.Acteurs)
                {
                    lstActeurs.Items.Add(acteur);
                }

            }
        }
    }
}