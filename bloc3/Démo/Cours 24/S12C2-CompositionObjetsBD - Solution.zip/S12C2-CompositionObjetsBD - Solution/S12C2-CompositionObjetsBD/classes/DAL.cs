﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12C2_CompositionObjetsBD.classes
{
    // <summary>
    /// Classe statique responsable des opérations d'accès aux données
    /// pour les films et les acteurs dans la base de données MySQL.
    /// </summary>
    public static class DAL
    {
        private const string APPSETTINGS_FILE = "appsettings.json";
        private const string CONNECTION_STRING_NAME = "DefaultConnection";

        private static readonly IConfiguration _config =
            new ConfigurationBuilder().AddJsonFile(APPSETTINGS_FILE).Build();

        /// <summary>
        /// Crée et retourne un objet MySqlConnection basé sur la configuration.
        /// </summary>
        /// <returns>Nouvelle connexion MySQL non ouverte.</returns>
        private static MySqlConnection CreerConnection()
        {
            string connectionString = _config.GetConnectionString(CONNECTION_STRING_NAME);
            return new MySqlConnection(connectionString);
        }

        /// <summary>
        /// Ferme et libère correctement une connexion MySQL si elle est ouverte.
        /// </summary>
        /// <param name="cn">Connexion à fermer.</param>
        private static void FermerConnection(MySqlConnection cn)
        {
            if (cn != null && cn.State == System.Data.ConnectionState.Open)
            {
                cn.Close();
                cn.Dispose();
            }
        }

     
        /// <summary>
        /// Récupère la liste complète des acteurs triés par ordre alphabétique.
        /// </summary>
        /// <returns>Liste d'objets Acteur.</returns>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de la lecture des acteurs.
        /// </exception>
        public static List<Acteur> ObtenirActeurs()
        {
            List<Acteur> lstActeurs = new List<Acteur>();
            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = "SELECT Id, Nom FROM acteurs ORDER BY Nom;";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                MySqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Acteur acteur = new Acteur(
                        dr.GetInt32(0),   // Id
                        dr.GetString(1)   // Nom
                    );

                    lstActeurs.Add(acteur);
                }

                dr.Close();
                dr.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la récupération des acteurs.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }

            return lstActeurs;
        }

        /// <summary>
        /// Ajoute un film dans la base de données ainsi que tous les acteurs
        /// associés dans la table film_acteurs. Retourne l'identifiant généré.
        /// </summary>
        /// <param name="film">Film à ajouter, incluant sa liste d'acteurs.</param>
        /// <returns>Identifiant généré du film.</returns>
        /// <exception cref="ArgumentNullException">
        /// Lancée si le film est null.
        /// </exception>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de l'insertion du film
        /// ou lors de l'association des acteurs.
        /// </exception>
        public static void AjouterFilm(Film film)
        {
            if (film == null)
                throw new ArgumentNullException(nameof(film), "Le film ne doit pas être null");

            MySqlConnection cn = CreerConnection();
           

            try
            {
                cn.Open();

                // -------------------------------------------------------------
                // 1) Insertion du film
                // -------------------------------------------------------------
                string requete = @"INSERT INTO films (Titre, Annee)
                                       VALUES (@titre, @annee);";

                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@titre", film.Titre);
                cmd.Parameters.AddWithValue("@annee", film.Annee);

                cmd.ExecuteNonQuery();

                film.Id = (int)cmd.LastInsertedId;
                

                // -------------------------------------------------------------
                // 2) Insertion des acteurs liés au film (table de liaison)
                // -------------------------------------------------------------
                requete = @"INSERT INTO film_acteurs (FilmId, ActeurId)
                                         VALUES (@filmId, @acteurId);";
                cmd.CommandText = requete;

                cmd.Parameters.Clear();
                cmd.Parameters.Add("@filmId", MySqlDbType.Int32).Value = film.Id;
                cmd.Parameters.Add("@acteurId", MySqlDbType.Int32);

                foreach (Acteur acteur in film.Acteurs)
                {
                    cmd.Parameters["@acteurId"].Value = acteur.Id;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de l'ajout du film et de ses acteurs.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }

           
        }


        /// <summary>
        /// Récupère la liste des films et charge aussi tous les acteurs associés
        /// en effectuant une seule requête SQL avec jointure.
        /// </summary>
        /// <returns>Liste complète d'objets Film incluant leurs acteurs.</returns>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de la lecture dans la base
        /// de données.
        /// </exception>
        public static List<Film> ObtenirFilms()
        {
            List<Film> lstFilms = new List<Film>();
            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = @"
                    SELECT f.Id, f.Titre, f.Annee,
                           a.Id, a.Nom
                    FROM films f
                    INNER JOIN film_acteurs fa ON fa.FilmId = f.Id
                    INNER JOIN acteurs a ON a.Id = fa.ActeurId
                    ORDER BY f.Annee DESC, f.Id, a.Nom;
                ";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                MySqlDataReader dr = cmd.ExecuteReader();

                
                Film? filmCourant = null;
                while (dr.Read())
                {
                    int filmId = dr.GetInt32(0);
                    // ---------------------------------------------------------
                    // Si on détecte un nouveau film, on instancie un nouvel objet
                    // ---------------------------------------------------------
                    if (filmCourant == null || filmId != filmCourant.Id)
                    {
                        filmCourant = new Film(
                            dr.GetInt32(0),      // Id
                            dr.GetString(1),     // Titre
                            dr.GetInt32(2)       // Année
                        );

                        lstFilms.Add(filmCourant);
                       
                    }

                    // ---------------------------------------------------------
                    // Ajout de l'acteur (si présent)
                    // ---------------------------------------------------------     
                    if (!dr.IsDBNull(3))
                    {
                        Acteur acteur = new Acteur(
                        dr.GetInt32(3),   // Id acteur
                        dr.GetString(4)   // Nom acteur
                        );

                        filmCourant.Acteurs.Add(acteur);
                    }
                    

                }

                dr.Close();
                dr.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la récupération des films et de leurs acteurs.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }

            return lstFilms;
        }

    }
}
