﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12C2_CompositionObjetsBD.classes
{
    using System.Collections.Generic;

    public class Film
    {
        private int _id;
        private string _titre;
        private int _annee;
        private List<Acteur> _acteurs;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Titre
        {
            get { return _titre; }
            set { _titre = value; }
        }

        public int Annee
        {
            get { return _annee; }
            set { _annee = value; }
        }

        public List<Acteur> Acteurs
        {
            get { return _acteurs; }
            set { _acteurs = value; }
        }

        public Film(int id, string titre, int annee)
        {
            Id = id;
            Titre = titre;
            Annee = annee;
            Acteurs = new List<Acteur>();
        }

        public void AjouterActeur(Acteur acteur)
        {
            Acteurs.Add(acteur);
        }

        public override string ToString()
        {
            return Titre + " (" + Annee + ")";
        }
    }

}
