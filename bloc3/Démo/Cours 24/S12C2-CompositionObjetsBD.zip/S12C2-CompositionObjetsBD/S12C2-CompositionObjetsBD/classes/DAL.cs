﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12C2_CompositionObjetsBD.classes
{
    // <summary>
    /// Classe statique responsable des opérations d'accès aux données
    /// pour les films et les acteurs dans la base de données MySQL.
    /// </summary>
    public static class DAL
    {
        private const string APPSETTINGS_FILE = "appsettings.json";
        private const string CONNECTION_STRING_NAME = "DefaultConnection";

        private static readonly IConfiguration _config =
            new ConfigurationBuilder().AddJsonFile(APPSETTINGS_FILE).Build();

        /// <summary>
        /// Crée et retourne un objet MySqlConnection basé sur la configuration.
        /// </summary>
        /// <returns>Nouvelle connexion MySQL non ouverte.</returns>
        private static MySqlConnection CreerConnection()
        {
            string connectionString = _config.GetConnectionString(CONNECTION_STRING_NAME);
            return new MySqlConnection(connectionString);
        }

        /// <summary>
        /// Ferme et libère correctement une connexion MySQL si elle est ouverte.
        /// </summary>
        /// <param name="cn">Connexion à fermer.</param>
        private static void FermerConnection(MySqlConnection cn)
        {
            if (cn != null && cn.State == System.Data.ConnectionState.Open)
            {
                cn.Close();
                cn.Dispose();
            }
        }


        /// <summary>
        /// Récupère la liste des films et charge aussi tous les acteurs associés
        /// en effectuant une seule requête SQL avec jointure.
        /// </summary>
        /// <returns>Liste complète d'objets Film incluant leurs acteurs.</returns>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de la lecture dans la base
        /// de données.
        /// </exception>
        public static List<Film> ObtenirFilms()
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Récupère la liste complète des acteurs triés par ordre alphabétique.
        /// </summary>
        /// <returns>Liste d'objets Acteur.</returns>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de la lecture des acteurs.
        /// </exception>
        public static List<Acteur> ObtenirActeurs()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Ajoute un film dans la base de données ainsi que tous les acteurs
        /// associés dans la table film_acteurs. Retourne l'identifiant généré.
        /// </summary>
        /// <param name="film">Film à ajouter, incluant sa liste d'acteurs.</param>
        /// <returns>Identifiant généré du film.</returns>
        /// <exception cref="ArgumentNullException">
        /// Lancée si le film est null.
        /// </exception>
        /// <exception cref="Exception">
        /// Lancée lorsqu'une erreur survient lors de l'insertion du film
        /// ou lors de l'association des acteurs.
        /// </exception>
        public static void AjouterFilm(Film film)
        {
            throw new NotImplementedException();
           
        }


    }
}
