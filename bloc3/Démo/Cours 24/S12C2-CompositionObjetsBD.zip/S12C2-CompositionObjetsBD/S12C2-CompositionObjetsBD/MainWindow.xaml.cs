﻿using S12C2_CompositionObjetsBD.classes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12C2_CompositionObjetsBD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ChargerActeurs();
            ChargerFilms();

        }

        private void ChargerActeurs()
        {
           
        }

        private void ChargerFilms()
        {
            
        }

        private void btnAjouterActeur_Click(object sender, RoutedEventArgs e)
        {
            if(cboActeurs.SelectedIndex != -1)
            {

                if (!lstActeurs.Items.Contains(cboActeurs.SelectedItem))
                    lstActeurs.Items.Add(cboActeurs.SelectedItem);

            }
        }

        private void btnAjouterFilm_Click(object sender, RoutedEventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            EffacerFormulaire();
        }

        private void EffacerFormulaire()
        {
            txtTitre.Clear();
            txtAnnee.Clear();
            lstActeurs.Items.Clear();
            cboActeurs.SelectedIndex = -1;
            lstFilms.SelectedIndex = -1;
        }

        private void lstFilms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }
    }
}