-- -------------------------------------------------------
--  Création de la base de données
-- -------------------------------------------------------
use demo_films;

-- -------------------------------------------------------
--  Table : acteurs
-- -------------------------------------------------------
CREATE TABLE acteurs (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Nom VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

-- -------------------------------------------------------
--  Table : films
-- -------------------------------------------------------
CREATE TABLE films (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Titre VARCHAR(200) NOT NULL,
    Annee INT NOT NULL
) ENGINE=InnoDB;

-- -------------------------------------------------------
--  Table de liaison : film_acteurs
-- -------------------------------------------------------
CREATE TABLE film_acteurs (
    FilmId INT NOT NULL,
    ActeurId INT NOT NULL,
    PRIMARY KEY (FilmId, ActeurId),

    FOREIGN KEY (FilmId)
        REFERENCES films(Id)
        ON DELETE CASCADE,

    FOREIGN KEY (ActeurId)
        REFERENCES acteurs(Id)
) ENGINE=InnoDB;

-- -------------------------------------------------------
--  Insertion de données de base (Acteurs)
-- -------------------------------------------------------
INSERT INTO acteurs (Nom) VALUES
    ('Leonardo DiCaprio'),
    ('Tom Hanks'),
    ('Scarlett Johansson'),
    ('Emma Stone'),
    ('Keanu Reeves'),
    ('Robert Downey Jr.'),
    ('Morgan Freeman'),
    ('Jennifer Lawrence'),
    ('Samuel L. Jackson'),
    ('Anne Hathaway'),
    ('Brad Pitt'),
    ('Natalie Portman'),
    ('Chris Evans'),
    ('Harrison Ford'),
    ('Meryl Streep');

-- -------------------------------------------------------
--  (Optionnel) Exemple de films
--  *Les étudiants peuvent en ajouter eux-mêmes.
-- -------------------------------------------------------

INSERT INTO films (Titre, Annee) VALUES
    ('Inception', 2010),
    ('Forrest Gump', 1994),
    ('La La Land', 2016),
    ('The Matrix', 1999),
    ('Avengers', 2012);

-- Associations film-acteurs
INSERT INTO film_acteurs VALUES
    (1, 1),   
    (2, 2),   
    (3, 4),   
    (4, 5),   
    (5, 6),   
    (5, 13);  

