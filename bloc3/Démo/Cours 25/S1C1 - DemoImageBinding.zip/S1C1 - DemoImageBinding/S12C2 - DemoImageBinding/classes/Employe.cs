﻿using S12C2_DemoImageBinding.enums;


namespace S12C2_DemoImageBinding.classes
{
    public class Employe
    {

        private string _nom;
        private string _prenom;
        private decimal _salaire;
        private TypeEmploi _typeEmploi;

        private string _image;



        public string Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        public string Prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }

        public decimal Salaire
        {
            get { return _salaire; }
            set { _salaire = value; }
        }

        public TypeEmploi TypeEmploi
        {
            get { return _typeEmploi; }
            set { _typeEmploi = value; }
        }

        public string Image
        {
            get { return _image; }
            set { _image = value; }
        }


        // Constructeur
        public Employe(string nom, string prenom, decimal salaire, TypeEmploi typeEmploi, string image)
        {

            Nom = nom;
            Prenom = prenom;
            Salaire = salaire;
            TypeEmploi = typeEmploi;
            Image = image;
        }


        public override string ToString()
        {
            return $"{Nom}, {Prenom}";
        }


    }
}
