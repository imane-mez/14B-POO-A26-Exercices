﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace S12C2___DemoImageBinding
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
