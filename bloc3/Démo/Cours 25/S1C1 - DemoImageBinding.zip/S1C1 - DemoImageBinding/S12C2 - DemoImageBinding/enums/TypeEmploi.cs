﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S12C2_DemoImageBinding.enums
{
    public enum TypeEmploi: byte
    {
        Ingenieur,
        Gestionnaire,
        Technicien,
        Administratif
    }
}
