﻿using Microsoft.Extensions.Configuration;
using Microsoft.Win32;
using S12C2_DemoImageBinding.classes;
using S12C2_DemoImageBinding.enums;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace S12C2___DemoImageBinding
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        // Lecture du appsettings.json
        IConfiguration _config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        private List<Employe> _employes;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

           

            //s'assurer que le dossier imgaes doit être dans le bin
          

            _employes = new List<Employe>();

            ChargerTypeEmplois();


        }

        private void ChargerTypeEmplois()
        {
            cboTypeEmploi.ItemsSource = Enum.GetNames(typeof(TypeEmploi));
        }

        private void btnParcourir_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Ajout d'une image");
            }

        }

        /// <summary>
        /// Permet l'affichage de l'image de l'employé
        /// </summary>
        /// <param name="cheminFichier">Chemin d'accès à l'image</param>
        private void AfficherImage(string cheminFichier)
        {


        }

        private void InitialiserFormulaire()
        {
            txtNom.Clear();
            txtPrenom.Clear();
            txtSalaire.Clear();
            cboTypeEmploi.SelectedIndex = -1;
            btnSupprimer.IsEnabled = false;
            btnAjouter.IsEnabled = true;
            imgEmploye.Source = null;

            btnModifier.IsEnabled = false;

          
        }



        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //todo : À compléter

                // Récupère l'image actuellement affichée afin de la copier
                // dans le dossier prévu par la configuration.


                // Chemin original de l'image sélectionnée


                // Générer un nouveau nom unique avec GUID


                // Destination dans le BIN (dossier images)


                // Chemin complet


                // Copier l’image originale vers le dossier BIN


                // Crée l'employé avec les valeurs saisies dans le formulaire.


                // Ajoute l'employé à la collection puis remet le formulaire à zéro.


            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Ajout d'un employé");
            }
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //todo : À compléter

                // Un employé doit être sélectionné avant de pouvoir le supprimer.

                
                // Supprime également la copie de l'image associée à l'employé.
                

                // Retire l'employé de la collection en mémoire.
                

                // Réinitialise les contrôles et actualise la liste affichée.
                

            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "suppression d'un employé");
            }

        }

        private void lstEmployes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //todo : À compléter

            // Recopie les données de l'employé sélectionné dans les champs du formulaire.

            // En mode modification, le bouton Ajouter est désactivé et
            // les boutons Modifier et Supprimer sont activés.
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //todo : À compléter

                // Récupère l'employé correspondant à la sélection actuelle.
                

                // Récupère l'image actuellement affichée dans le contrôle.
                

                // Compare le chemin affiché avec celui enregistré pour savoir
                // si une nouvelle copie de l'image est nécessaire.
                

             
                    // Générer un nouveau nom unique
               
                    // Dossier d’images (relatif)
                
                    // Convertir en chemin complet
                  
                    // Si le dossier n'existe pas encore, alors il sera créé par CreaeteDirectory. Cela évite une exception si le dossier a été supprimé entre-temps.
                  
                    // Copier l’image
                  
                    // Remplace le chemin de l'image par celui de la nouvelle copie.
                  

                // Met à jour les propriétés avec les valeurs du formulaire.
                

                // Rafraîchit la liste des employés.
                
            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Modification d'un employé");
            }

        }
    }
}