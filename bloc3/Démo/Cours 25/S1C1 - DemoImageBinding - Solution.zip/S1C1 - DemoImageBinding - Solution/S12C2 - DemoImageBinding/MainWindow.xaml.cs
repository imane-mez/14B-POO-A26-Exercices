﻿using Microsoft.Extensions.Configuration;
using Microsoft.Win32;
using S12C2_DemoImageBinding.classes;
using S12C2_DemoImageBinding.enums;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;


namespace S12C2___DemoImageBinding
{
 
    public partial class MainWindow : Window
    {


        // Charge la configuration afin de connaître le dossier où les images
        // des employés doivent être copiées.
        IConfiguration _config = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
            .Build();

        // liste des employés en mémoire.
        private List<Employe> _employes;

        public MainWindow()
        {
            
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Crée le dossier d'images s'il n'existe pas encore.
            if (!Directory.Exists(_config["images:path"]))
                Directory.CreateDirectory(_config["images:path"]);

            // Initialise la collection avant de l'utiliser dans le formulaire.
            _employes = new List<Employe>();

            lstEmployes.ItemsSource = _employes;

            // Remplit la liste déroulante avec les valeurs de l'énumération.
            ChargerTypeEmplois();
        }

        private void ChargerTypeEmplois()
        {
            // Utilise les noms de l'énumération comme choix proposés à l'utilisateur.
            cboTypeEmploi.ItemsSource = Enum.GetNames(typeof(TypeEmploi));
        }

        private void btnParcourir_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Ouvre une boîte de dialogue limitée aux formats d'image acceptés.
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Filter = "Images (*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";

                if (dlg.ShowDialog() == true)
                {
                    // Affiche l'image choisie dans le contrôle Image du formulaire.
                    AfficherImage(dlg.FileName);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Ajout d'une image");
            }

        }

        /// <summary>
        /// Permet l'affichage de l'image de l'employé
        /// </summary>
        /// <param name="cheminFichier">Chemin d'accès à l'image</param>
        private void AfficherImage(string cheminFichier)
        {
            // Évite de tenter de charger un chemin vide ou un fichier inexistant.
            if (!string.IsNullOrWhiteSpace(cheminFichier) && File.Exists(cheminFichier))
            {
                //imgEmploye.Source = new BitmapImage(new Uri(System.IO.Path.GetFullPath(cheminFichier)));

                BitmapImage bmp = new BitmapImage();
                bmp.BeginInit();                                              // Début de l'initialisation de l'objet BitmapImage

                bmp.CacheOption = BitmapCacheOption.OnLoad;                   // Charge l'image entièrement en mémoire et libère
                                                                              // immédiatement le fichier → évite les fichiers verrouillés

                bmp.UriSource = new Uri(cheminFichier, UriKind.Absolute);     // Spécifie le chemin complet de l'image à charger

                bmp.CreateOptions = BitmapCreateOptions.IgnoreImageCache;     // Force WPF à recharger l'image depuis le disque
                                                                              // (utile si un fichier existant a été modifié)

                bmp.EndInit();                                                // Fin de l'initialisation → l'image est définitivement chargée

                // Associe l'image chargée au contrôle Image du formulaire.
                imgEmploye.Source = bmp;

            }
            else
            {
                // Efface l'image si le chemin fourni n'est pas valide.
                imgEmploye.Source = null;
            }
        }

        private void InitialiserFormulaire()
        {
            // Réinitialise les champs saisis pour préparer une nouvelle opération.
            txtNom.Clear();
            txtPrenom.Clear();
            txtSalaire.Clear();
            cboTypeEmploi.SelectedIndex = -1;
            btnSupprimer.IsEnabled = false;
            btnAjouter.IsEnabled = true;
            imgEmploye.Source = null;

            btnModifier.IsEnabled = false;

            // Réaffecte la source pour que la liste reflète les ajouts,
            // suppressions ou modifications effectués en mémoire.
            lstEmployes.Items.Refresh();
        }



        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Récupère l'image actuellement affichée afin de la copier
                // dans le dossier prévu par la configuration.
                BitmapImage bmp = imgEmploye.Source as BitmapImage;

                // Chemin original de l'image sélectionnée
                string cheminOriginal = bmp.UriSource.LocalPath;

                // Générer un nouveau nom unique avec GUID
                string nouveauNom = Guid.NewGuid().ToString() + Path.GetExtension(cheminOriginal);

                // Destination dans le BIN (dossier images)
                string destination = Path.Combine(_config["images:path"], nouveauNom);

                // Chemin complet (absolu)
                string destinationComplet = Path.GetFullPath(destination);

                // Copier l’image originale vers le dossier BIN
                File.Copy(cheminOriginal, destination, overwrite: true);


                // Crée l'employé avec les valeurs saisies dans le formulaire.
                Employe emp = new Employe(
                    txtNom.Text,
                    txtPrenom.Text,
                    decimal.Parse(txtSalaire.Text),
                    (TypeEmploi)cboTypeEmploi.SelectedIndex,
                    destinationComplet
                );

                // Ajoute l'employé à la collection puis remet le formulaire à zéro.
                _employes.Add(emp);
                InitialiserFormulaire();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Ajout d'un employé");
            }
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            // Annule la saisie ou la sélection actuelle et prépare un formulaire vide.
            InitialiserFormulaire();
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Employe emp = lstEmployes.SelectedItem as Employe;

                // Un employé doit être sélectionné avant de pouvoir le supprimer.
                if (emp is null)
                {
                    MessageBox.Show("Veuillez sélectionner un employé à supprimer.");
                }

                else
                {
                    // Supprime également la copie de l'image associée à l'employé.
                    if (!string.IsNullOrWhiteSpace(emp.Image) && File.Exists(emp.Image))
                    {
                        File.Delete(emp.Image);
                    }

                    // Retire l'employé de la collection en mémoire.
                    _employes.Remove(emp);

                    // Réinitialise les contrôles et actualise la liste affichée.
                    InitialiserFormulaire();
                }
                

            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "suppression d'un employé");
            }

        }

        private void lstEmployes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Recopie les données de l'employé sélectionné dans les champs du formulaire.
            if (lstEmployes.SelectedItem is Employe emp)
            {
                txtNom.Text = emp.Nom;
                txtPrenom.Text = emp.Prenom;
                txtSalaire.Text = emp.Salaire.ToString();
                cboTypeEmploi.SelectedIndex = (int) emp.TypeEmploi;

                AfficherImage(emp.Image);

                // En mode modification, le bouton Ajouter est désactivé et
                // les boutons Modifier et Supprimer sont activés.
                btnAjouter.IsEnabled = false;
                btnModifier.IsEnabled = true;
                btnSupprimer.IsEnabled = true;
            }
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Récupère l'employé correspondant à la sélection actuelle.
                Employe emp = lstEmployes.SelectedItem as Employe;

                // Récupère l'image actuellement affichée dans le contrôle.
                BitmapImage bmp = imgEmploye.Source as BitmapImage;

                if (bmp == null || bmp.UriSource == null)
                    MessageBox.Show("Aucune image affichée.");

                string cheminAffiche = bmp.UriSource.LocalPath;   // Chemin d'accès de l'image sélectionnée
                string cheminEnregistre = emp.Image;              // chemin complet le l'image de l'employé sélectionné (bin/images/GUID.jpg)


                // Compare le chemin affiché avec celui enregistré pour savoir
                // si une nouvelle copie de l'image est nécessaire.
                bool nouvelleImage =
                    !string.Equals(cheminAffiche, cheminEnregistre, StringComparison.OrdinalIgnoreCase);


                if (nouvelleImage)
                {
                    // Générer un nouveau nom unique
                    string nouveauNom = Guid.NewGuid().ToString() + Path.GetExtension(cheminAffiche);

                    // Dossier d’images (relatif)
                    string destinationRelatif = Path.Combine(_config["images:path"], nouveauNom);

                    // Convertir en chemin complet
                    string destinationComplet = Path.GetFullPath(destinationRelatif);

                    // Si le dossier n'existe pas encore, alors il sera créé par CreaeteDirectory. Cela évite une exception si le dossier a été supprimé entre-temps.
                    Directory.CreateDirectory(_config["images:path"]);

                    // Copier l’image
                    File.Copy(cheminAffiche, destinationComplet, overwrite: true);

                    // Remplace le chemin de l'image par celui de la nouvelle copie.
                    emp.Image = destinationComplet;
                }

                // Met à jour les propriétés avec les valeurs du formulaire.
                emp.Nom = txtNom.Text;
                emp.Prenom = txtPrenom.Text;
                emp.Salaire = decimal.Parse(txtSalaire.Text);
                emp.TypeEmploi = (TypeEmploi)cboTypeEmploi.SelectedIndex;

                // Quitte le mode modification et rafraîchit la liste des employés.
                InitialiserFormulaire();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite :\n" + ex.Message, "Modification d'un employé");
            }

        }
    }
}