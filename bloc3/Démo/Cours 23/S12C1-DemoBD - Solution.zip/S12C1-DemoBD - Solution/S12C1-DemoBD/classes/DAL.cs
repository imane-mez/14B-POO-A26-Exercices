﻿using Microsoft.Extensions.Configuration;
using MySqlConnector;
using S12C1_DemoBD.enums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace S12C1_DemoBD.classes
{
    /// <summary>
    /// Classe statique responsable des opérations d'accès aux données (DAL).
    /// Contient les méthodes permettant d'interagir avec la base MySQL :
    /// récupération, insertion, modification et suppression d'employés.
    /// </summary>
    public static class DAL
    {

        private const string APPSETTINGS_FILE = "appsettings.json";

        /// <summary>
        /// Nom de la chaîne de connexion définie dans le appsettings.json.
        /// </summary>
        private const string CONNECTION_STRING_NAME = "DefaultConnection";

        // Chargement de la configuration une seule fois à l'exécution.
        private static readonly IConfiguration _config =
            new ConfigurationBuilder().AddJsonFile(APPSETTINGS_FILE).Build();


        /// <summary>
        /// Crée et retourne un objet <see cref="MySqlConnection"/> configuré
        /// avec la chaîne de connexion définie dans le appsettings.json.
        /// La connexion n'est pas ouverte ici.
        /// </summary>
        /// <returns>Nouvelle connexion MySQL non ouverte.</returns>
        private static MySqlConnection CreerConnection()
        {
            string connectionString = _config.GetConnectionString(CONNECTION_STRING_NAME);
            return new MySqlConnection(connectionString);
        }

        /// <summary>
        /// Ferme et libère correctement une connexion MySQL.
        /// Cette méthode est utilisée dans les blocs finally afin de garantir
        /// la libération de la ressource même en cas d'exception.
        /// </summary>
        /// <param name="cn">Connexion MySQL à fermer.</param>
        private static void FermerConnection(MySqlConnection cn)
        {
            if (cn != null && cn.State == System.Data.ConnectionState.Open)
            {
                cn.Close();     // Ferme la connexion active
                cn.Dispose();   // Libère la ressource (bonne pratique ADO.NET)
            }
        }


        /// <summary>
        /// Récupère et retourne la liste complète des employés,
        /// triée par nom puis par prénom en ordre alphabétique.
        /// </summary>
        /// <returns>Liste d'objets <see cref="Employe"/>.</returns>
        public static Employe ObtenirEmploye(uint id)
        {
            MySqlConnection cn = CreerConnection();
            Employe? employe = null;

            try
            {
                cn.Open();

                string requete =
                    "SELECT Id, Nom, Prenom, Salaire, TypeEmploi FROM Employes where id=@id";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                cmd.Parameters.AddWithValue("@id", id);

                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    employe = new Employe(
                    dr.GetUInt32(0),
                    dr.GetString(1),
                    dr.GetString(2),
                    dr.GetDecimal(3),
                    (TypeEmploi)dr.GetByte(4));
                }
                

                dr.Close();
                dr.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la récupération de l'employé.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }

            return employe;
        }

        /// <summary>
        /// Récupère et retourne la liste complète des employés,
        /// triée par nom puis par prénom en ordre alphabétique.
        /// </summary>
        /// <returns>Liste d'objets <see cref="Employe"/>.</returns>
        public static List<Employe> ObtenirListeEmployes()
        {
            MySqlConnection cn = CreerConnection();
            List<Employe> lstEmployes = new List<Employe>();

            try
            {
                cn.Open();

                string requete =
                    "SELECT Id, Nom, Prenom, Salaire, TypeEmploi FROM Employes ORDER BY Nom, Prenom";

                MySqlCommand cmd = new MySqlCommand(requete, cn);
                
                MySqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    Employe employe = new Employe(
                        dr.GetUInt32(0),
                        dr.GetString(1),
                        dr.GetString(2),
                        dr.GetDecimal(3),
                        (TypeEmploi)dr.GetByte(4)
                    );

                    lstEmployes.Add(employe);
                }

                dr.Close();
                dr.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la récupération de la liste des employés.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }

            return lstEmployes;
        }

        /// <summary>
        /// Ajoute un nouvel employé dans la base de données.
        /// L'identifiant n'est pas fourni : il est automatiquement généré par MySQL.
        /// </summary>
        /// <param name="employe">Employé à ajouter.</param>
        /// <exception cref="ArgumentNullException">Si l'objet employe est null.</exception>
        public static void Ajouter(Employe employe)
        {
            if (employe == null)
                throw new ArgumentNullException(nameof(employe), "L'employe ne doit pas être null");

            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = @"INSERT INTO Employes (Nom, Prenom, Salaire, TypeEmploi) 
                                   VALUES(@nom, @prenom, @salaire, @typeEmploi);";

                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@nom", employe.Nom);
                cmd.Parameters.AddWithValue("@prenom", employe.Prenom);
                cmd.Parameters.AddWithValue("@salaire", employe.Salaire);
                cmd.Parameters.AddWithValue("@typeEmploi", employe.TypeEmploi);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de l'ajout de l'employé dans la base de données.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }
        }

        /// <summary>
        /// Modifie les informations d'un employé existant dans la base de données.
        /// </summary>
        /// <param name="employe">Employé contenant les nouvelles valeurs.</param>
        /// <exception cref="ArgumentNullException">Si l'objet employe est null.</exception>
        public static void Modifier(Employe employe)
        {
            if (employe == null)
                throw new ArgumentNullException(nameof(employe), "L'employe ne doit pas être null");

            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = @"UPDATE Employes SET 
                                      Nom = @nom,
                                      Prenom = @prenom,
                                      Salaire = @salaire,
                                      TypeEmploi = @typeEmploi
                                   WHERE Id = @id;";

                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@id", employe.Id);
                cmd.Parameters.AddWithValue("@prenom", employe.Prenom);
                cmd.Parameters.AddWithValue("@nom", employe.Nom);
                cmd.Parameters.AddWithValue("@salaire", employe.Salaire);
                cmd.Parameters.AddWithValue("@typeEmploi", employe.TypeEmploi);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la modification de l'employé dans la base de données.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }
        }

        /// <summary>
        /// Supprime un employé de la base de données à partir de son identifiant unique.
        /// </summary>
        /// <param name="id">Identifiant de l'employé à supprimer.</param>
        /// <exception cref="ArgumentOutOfRangeException">Si l'identifiant est inférieur à 1.</exception>
        public static void Supprimer(long id)
        {
            if (id < 1)
                throw new ArgumentOutOfRangeException("L'identifiant doit être supérieur à 0.", nameof(id));

            MySqlConnection cn = CreerConnection();

            try
            {
                cn.Open();

                string requete = "DELETE FROM Employes WHERE Id = @id;";
                MySqlCommand cmd = new MySqlCommand(requete, cn);

                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la suppression de l'employé dans la base de données.", ex);
            }
            finally
            {
                FermerConnection(cn);
            }
        }

    }
}
