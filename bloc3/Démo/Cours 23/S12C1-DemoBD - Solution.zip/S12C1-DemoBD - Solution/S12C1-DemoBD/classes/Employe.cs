﻿using S12C1_DemoBD.enums;

namespace S12C1_DemoBD.classes
{
    public class Employe
    {
        private uint _id;
        private string _nom;
        private string _prenom;
        private decimal _salaire;
        private TypeEmploi _typeEmploi;

      

        public uint Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public string Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        public string Prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }

        public decimal Salaire
        {
            get { return _salaire; }
            set { _salaire = value; }
        }

        public TypeEmploi TypeEmploi
        {
            get { return _typeEmploi; }
            set { _typeEmploi = value; }
        }

        // Constructeur
        public Employe(uint id, string nom, string prenom, decimal salaire, TypeEmploi typeEmploi)
        {
            Id = id;
            Nom = nom;
            Prenom = prenom;
            Salaire = salaire;
            TypeEmploi = typeEmploi;
        }


        public override string ToString()
        {
            return $"{Nom}, {Prenom}"; 
        }
      

    }
}
