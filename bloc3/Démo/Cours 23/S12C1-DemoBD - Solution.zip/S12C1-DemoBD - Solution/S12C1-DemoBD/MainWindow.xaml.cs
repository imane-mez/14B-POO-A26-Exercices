﻿using S12C1_DemoBD.classes;
using S12C1_DemoBD.enums;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12C1_DemoBD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            cboTypeEmploi.ItemsSource = Enum.GetNames(typeof(TypeEmploi));
            AfficherListeEmployes();
        }

        private void AfficherListeEmployes()
        {
            try
            {
                lstEmployes.ItemsSource = DAL.ObtenirListeEmployes();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Erreur");
            }
           
        }

        private void InitialiserFormulaire()
        {
            txtNom.Clear();
            txtPrenom.Clear();
            txtSalaire.Clear();
            cboTypeEmploi.SelectedIndex = -1;
            btnSupprimer.IsEnabled = false;
            btnAjouter.IsEnabled = true;
            lstEmployes.SelectedIndex = -1;
        }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //TODO : Validation à effectuer avant l'ajout

                //Création d'un nouvel employe
                Employe employe = new Employe(0, txtNom.Text, txtPrenom.Text, decimal.Parse(txtSalaire.Text), (TypeEmploi)cboTypeEmploi.SelectedIndex);

                //Appel de la méthode du DAL pour l'ajout du employe dans la BD
                DAL.Ajouter(employe);

                //Mise à jour de l'interface
                InitialiserFormulaire();
                AfficherListeEmployes();

                MessageBox.Show("L'employé a été ajouté avec succès!", "Ajout d'un employé");

            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite : " + ex.Message, "Ajout d'un employé");
            }
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Ici il serait préférable d'obtenir l'employé de la base de donnée pour être
                //certain d'avoir l'information la plus à jour.
                Employe employeSelec = (Employe)this.lstEmployes.SelectedItem;

                // Est-ce qu'un employe a été sélectionné dans le ListBox ?
                if (employeSelec == null)
                    MessageBox.Show("Vous devez sélectionner un employe dans la liste.", "Suppression d'un employe");
                else
                {
                    //Affichage du message de confirmation à l'utilisateur
                    MessageBoxResult resultat = MessageBox.Show("Désirez-vous vraiment supprimer ce employe?", "Suppression d'un employe", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    //Si l'utilisateur désire suppprimer le employe
                    if (resultat == MessageBoxResult.Yes)
                    {

                        //Appel de la méthode permettant la suppression d'un employe
                        DAL.Supprimer(employeSelec.Id);

                        //Mise à jour de l'interface
                        InitialiserFormulaire();
                        AfficherListeEmployes();

                        MessageBox.Show("La suppression s'est effectuée avec succès.", "Suppression d'un employé");

                    }


                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Une erreur s'est produite : " + ex.Message, "Suppression d'un employé");
            }
        }

        private void lstEmployes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstEmployes.SelectedItem is not null)
            {
                // récupérer l'employé sélectionné dans le ListBox
                Employe employeSel = (Employe)lstEmployes.SelectedItem;
                // Aller chercher les informations à jour de cet employé dans la BD en passant l'id en paramètre
                // Attention : ici il ne faut pas passer lstEmployes.SelectedIndex car l'indice dans la liste n'est pas forcément l'identifiant de l'employé
                Employe employeBD = DAL.ObtenirEmploye(employeSel.Id);

                txtNom.Text = employeBD.Nom;
                txtPrenom.Text = employeBD.Prenom;
                txtSalaire.Text = employeBD.Salaire.ToString();
                cboTypeEmploi.SelectedIndex = (byte)employeBD.TypeEmploi;

                btnAjouter.IsEnabled = false;
                btnSupprimer.IsEnabled = true;
            }
        }
    }
}