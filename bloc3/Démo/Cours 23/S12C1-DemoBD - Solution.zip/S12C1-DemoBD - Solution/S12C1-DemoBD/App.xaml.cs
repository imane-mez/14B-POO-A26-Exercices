﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace S12C1_DemoBD
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
