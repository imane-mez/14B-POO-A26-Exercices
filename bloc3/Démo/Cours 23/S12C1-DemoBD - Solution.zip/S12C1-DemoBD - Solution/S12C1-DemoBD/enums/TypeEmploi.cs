﻿
namespace S12C1_DemoBD.enums
{
    public enum TypeEmploi: byte
    {
        Ingenieur,
        Gestionnaire,
        Technicien,
        Administratif
    }
}
