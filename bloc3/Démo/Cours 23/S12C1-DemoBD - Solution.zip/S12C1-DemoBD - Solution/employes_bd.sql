-- --------------------------------------------------------
-- Base de données : employes_bd
-- --------------------------------------------------------

-- Suppression de la table si elle existe déjà
DROP TABLE IF EXISTS `employes`;

-- Création de la table employes
CREATE TABLE `employes` (
  `Id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `Nom` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Prenom` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `Salaire` DECIMAL(10,2) NOT NULL,
  `TypeEmploi` TINYINT NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB 
  DEFAULT CHARSET=utf8mb4 
  COLLATE=utf8mb4_general_ci;
