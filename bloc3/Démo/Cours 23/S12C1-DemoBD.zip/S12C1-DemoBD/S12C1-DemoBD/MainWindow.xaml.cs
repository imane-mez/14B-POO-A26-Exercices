﻿using S12C1_DemoBD.classes;
using S12C1_DemoBD.enums;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S12C1_DemoBD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {


        }

        private void AfficherListeEmployes()
        {
            //todo: À compléter
            throw new NotImplementedException();
        }

        private void InitialiserFormulaire()
        {
            txtNom.Clear();
            txtPrenom.Clear();
            txtSalaire.Clear();
            cboTypeEmploi.SelectedIndex = -1;
            btnSupprimer.IsEnabled = false;
            btnAjouter.IsEnabled = true;
            lstEmployes.SelectedIndex = -1;
        }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            //todo: À compléter
            throw new NotImplementedException();
        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            //todo: À compléter
            throw new NotImplementedException();
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            //todo: À compléter
            throw new NotImplementedException();
        }

        private void lstEmployes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstEmployes.SelectedItem is not null)
            {
                Employe employe = lstEmployes.SelectedItem as Employe;

                txtNom.Text = employe.Nom;
                txtPrenom.Text = employe.Prenom;
                txtSalaire.Text = employe.Salaire.ToString();
                cboTypeEmploi.SelectedIndex = (byte)employe.TypeEmploi;

                btnAjouter.IsEnabled = false;
                btnSupprimer.IsEnabled = true;
            }
        }
    }
}