﻿
using DemoCrud.classes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoCrud
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private List<Employe> _employes;



        public MainWindow()
        {
            _employes = new List<Employe>();

            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {


            // Ajout de cinq employés "hard-coded" pour ne pas avoir une liste vide au démarrage de l'application.
            // *** POUR FIN DE DÉMONSTRATION UNIQUEMENT ***
            _employes.Add(new Employe(Guid.NewGuid(), "Pierre Larouche", new DateTime(1966, 10, 18), 1355.00m));
            _employes.Add(new Employe(Guid.NewGuid(), "Annie Brocoli", new DateTime(1998, 06, 22), 999.00m));
            _employes.Add(new Employe(Guid.NewGuid(), "César Babiche", new DateTime(2005, 12, 01), 9.95m));
            _employes.Add(new Employe(Guid.NewGuid(), "Julie Lamontagne", new DateTime(1992, 09, 09), 56m));
            _employes.Add(new Employe(Guid.NewGuid(), "Anthony Beaudoin", new DateTime(2001, 03, 12), 44.56m));

            InitialiserListeEmploye();


        }

        private void InitialiserListeEmploye()
        {
            //On vide la liste
            lstEmployes.Items.Clear();

            // Ajout des employés dans le ListBox.
            foreach (Employe employe in _employes)
            {
                lstEmployes.Items.Add(employe);
            }
        }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {


        }

        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {

        }

    }
}