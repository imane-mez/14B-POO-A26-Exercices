﻿using S8C1_DemoMultiFormulaireCRUD.classes;
using S8C1_DemoMultiFormulaireCRUD.enumerations;
using System;
using System.Windows;

namespace S8C1_DemoMultiFormulaireCRUD
{
    /// <summary>
    /// Logique d'interaction pour FormAjoutEmploye.xaml
    /// </summary>
    public partial class FormAjoutEmploye : Window
    {
       

        /// <summary>
        /// L'employé à ajouter.
        /// </summary>
        private Employe _employeAjout;

        private EtatFormulaire _etat;

        public EtatFormulaire Etat
        {
            get { return _etat; }
            set { _etat = value; }
        }

        /// <summary>
        /// L'employé à ajouter.
        /// </summary>
        public Employe Employe
        {
            get { return _employeAjout; }
            private set { _employeAjout = value; }
        }

     

        public FormAjoutEmploye(Employe employe = null, EtatFormulaire etatFormulaire = EtatFormulaire.Ajouter)
        {
            InitializeComponent();
            Employe = employe;
            Etat = etatFormulaire;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
        }

        /// <summary>
        /// Permet l'initialisation du formulaire
        /// </summary>
        private void InitialiserFormulaire()
        {
           
            txtNom.Clear();
            txtSalaire.Clear();
            dpDateNaissance.SelectedDate = null;
            txtNom.Focus();

        }


        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            //todo: *** VALIDATION À EFFECTUER ÉVENTUELLEMENT ***

            // Récupération des données pour l'employé.
            string nom = txtNom.Text.Trim();
            DateOnly dateNaissance = DateOnly.FromDateTime((DateTime)dpDateNaissance.SelectedDate);
            decimal salaire = decimal.Parse(txtSalaire.Text);

           
            // Création de l'objet "Employe" et conservation dans la propriété "Employe".
            Employe = new Employe(Guid.NewGuid(), nom, dateNaissance, salaire);

            // Configuration du DialogResult ce qui fermera le formulaire sans le détruire et
            // retournera le contrôle de l'exécution au formulaire principal.
            DialogResult = true;
                 
        }

        private void btnAnnuler_Click(object sender, RoutedEventArgs e)
        {
            // Configuration du DialogResult ce qui fermera le formulaire sans le détruire et
            // retournera le contrôle de l'exécution au formulaire principal.
            DialogResult = false;
        }
    }
}
