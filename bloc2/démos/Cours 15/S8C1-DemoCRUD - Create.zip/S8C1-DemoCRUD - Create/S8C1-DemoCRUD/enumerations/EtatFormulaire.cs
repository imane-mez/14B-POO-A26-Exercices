﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S8C1_DemoMultiFormulaireCRUD.enumerations
{
    public enum EtatFormulaire
    {
        Ajouter,
        Modifier,
        Supprimer
    }
}
