﻿using S8C1_DemoMultiFormulaireCRUD.classes;
using System;
using System.Collections.Generic;
using System.Windows;

namespace S8C1_DemoMultiFormulaireCRUD
{
    /// <summary>
    /// Fenêtre principale de l’application de gestion des employés.
    /// Cette fenêtre permet d’afficher la liste des employés et d’en ajouter de nouveaux à l’aide d’un formulaire secondaire.
    /// </summary>
    public partial class FormGestionEmployes : Window
    {
    
        /// <summary>
        /// Contient la liste des employés utilisée dans le formulaire
        /// </summary>
        private List<Employe> _employes;

   
        public FormGestionEmployes()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Instanciation de la liste des employés.
            _employes = new List<Employe>();

            // Ajout de cinq employés "hard-coded" pour ne pas avoir une liste vide au démarrage de l'application.
            // *** POUR FIN DE DÉMONSTRATION UNIQUEMENT ***
            _employes.Add(new Employe(Guid.NewGuid(),"Pierre Larouche", new DateOnly(1966, 10, 18), 1355.00m));
            _employes.Add(new Employe(Guid.NewGuid(), "Annie Brocoli", new DateOnly(1998, 06, 22), 999.00m));
            _employes.Add(new Employe(Guid.NewGuid(), "César Babiche", new DateOnly(2005, 12, 01), 9.95m));
            _employes.Add(new Employe(Guid.NewGuid(), "Julie Lamontagne", new DateOnly(1992, 09, 09), 56m));
            _employes.Add(new Employe(Guid.NewGuid(), "Anthony Beaudoin", new DateOnly(2001, 03, 12), 44.56m));


            // Affiche la liste des employés à l’écran.
            AfficherListeEmployes();

          
        }

        /// <summary>
        /// Affiche la liste des employés dans le contrôle visuel ListBox (<c>lstEmployes</c>).
        /// </summary>
        /// <remarks>
        /// Vide d’abord la liste, puis ajoute chaque employé contenu dans la collection <see cref="_employes"/>.
        /// </remarks>
        private void AfficherListeEmployes()
        {
            //On vide la liste
            lstEmployes.Items.Clear();

            // Ajout des employés dans le ListBox.
            foreach(Employe employe in _employes)
            {
                lstEmployes.Items.Add(employe);
            }
        }

        /// <summary>
        /// Événement déclenché lorsque l’utilisateur clique sur le bouton "Ajouter".
        /// </summary>
        /// <remarks>
        /// Ouvre un formulaire secondaire (<see cref="FormAjoutEmploye"/>) pour créer un nouvel employé.
        /// Une fois le formulaire fermé, le nouvel employé est ajouté à la liste principale si la création a été confirmée.
        /// </remarks>

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            // Création du formulaire pour ajouter un employé.
            FormAjoutEmploye frmAjoutEmploye = new FormAjoutEmploye();

            // Après la fermeture du formulaire d'ajout d'un employé, l'exécution du code se poursuit ici.
            if (frmAjoutEmploye.ShowDialog() == true)
            {
                // Récupération de l'employé qui a été créé dans l'autre formulaire.
                Employe nouvEmploye = frmAjoutEmploye.Employe;

                //Ajout du nouvel employé à la liste d'employé
                _employes.Add(nouvEmploye);

                //Réinitialisation de la liste des employés
                AfficherListeEmployes();

                // Rétroaction pour confirmer à l'utilisateur le succès de l'opération.
                MessageBox.Show("L'employé suivant a été ajouté :\n" + nouvEmploye.ToString(),
                    "Employé ajouté avec succès", MessageBoxButton.OK, MessageBoxImage.Information);

            }

        }

        /// <summary>
        /// Événement déclenché lorsque l’utilisateur clique sur le bouton "Quitter".
        /// </summary>
        /// <remarks>
        /// Ferme simplement la fenêtre principale et met fin à l’application.
        /// </remarks>
        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {

        }
    }

}
       

      
    

