﻿
using System;

namespace S8C1_DemoMultiFormulaireCRUD.classes

{
    /// <summary>
    /// Représente un employé d'une compagnie.
    /// </summary>
    public class Employe
    {
        

        /// <summary>
        /// Identifiant unique de l'employé
        /// </summary>
        private Guid _id;

      

        /// <summary>
        /// Nom complet de l'employé.
        /// </summary>
        private String _nom;

        /// <summary>
        /// Date de naissance
        /// </summary>
        private DateOnly _dateNaissance;

        /// <summary>
        /// Salaire hebdomadaire de l'employé.
        /// </summary>
        private decimal _salaireHebdo;



        /// <summary>
        /// Obtient ou définit l'identifiant unique d'un employé
        /// </summary>
        public Guid Id
        {
            get { return _id; }
            private set { _id = value; }
        }

        /// <summary>
        /// Nom complet de l'employé.
        /// </summary>
        public String Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        /// <summary>
        /// Âge de l'employé.
        /// </summary>
        public DateOnly DateNaissance
        {
            get { return _dateNaissance; }
            set { _dateNaissance = value; }
        }

        /// <summary>
        /// Salaire hebdomadaire de l'employé.
        /// </summary>
        public decimal SalaireHebdo
        {
            get { return _salaireHebdo; }
            set { _salaireHebdo = value; }
        }



  

        /// <summary>
        /// Constructeur paramétré pour un employé.
        /// </summary>
        /// <param name="id">Identifiant unique de l'employé</param>
        /// <param name="nom">Nom de l'employé.</param>
        /// <param name="dateNaissance">Date de naissance de l'employé.</param>
        /// <param name="salaireHebdo">Salaire hebdomadaire de l'employé.</param>
        public Employe(Guid id, String nom, DateOnly dateNaissance, decimal salaireHebdo)
        {
            Id = id;
            Nom = nom;
            DateNaissance = dateNaissance;
            SalaireHebdo = salaireHebdo;

        }

        
        /// <summary>
        /// Permet d'obtenir une représentation de l'employé.
        /// </summary>
        /// <returns>Un représentation de l'employé sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {

            return $"{Nom} né(e) en {DateNaissance.ToShortDateString()}";
        }
        
    }
}
