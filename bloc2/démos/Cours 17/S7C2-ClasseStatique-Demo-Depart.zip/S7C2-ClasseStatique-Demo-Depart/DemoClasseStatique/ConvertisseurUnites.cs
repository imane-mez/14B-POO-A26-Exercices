﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoClasseStatique
{
    /// <summary>
    /// Classe statique permettant la conversion d'unitées.
    /// </summary>
    public static class ConvertisseurUnites
    {

        /// <summary>
        /// Permet la conversion de centimètres en pouces.
        /// </summary>
        /// <param name="pCentimetres">Nombre de centimètres à convertir en pouces</param>
        /// <returns>Nombre de pouces</returns>
        public static float CentimetresEnPouces(float pCentimetres)
        {
            return pCentimetres / 2.54f;
        }

        /// <summary>
        /// Permet la conversion de pouces en centimètres
        /// </summary>
        /// <param name="pPouces">Nombre de pouces à convertir</param>
        /// <returns>Nombre de centimètres</returns>
        public static float PoucesEnCentimetres(float pPouces)
        {
            return pPouces * 2.54f;
        }
    }
}
