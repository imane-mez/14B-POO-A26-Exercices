﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace DemoClasseStatique
{
    public class Chat
    {
        /// <summary>
        /// Attribut static qui sera utilisé par toutes les instances de la classe.
        /// </summary>
        

        /// <summary>
        /// Constructeur
        /// </summary>
        public Chat()
        {
            //À chaque fois qu'un objet est instancié, on incrémente le nombre d'instance de la classe.
            
        }


        /// <summary>
        /// Méthode static permettant d'obtenir le nombre d'instances de la classe.
        /// </summary>
        /// <returns>Nombre d'instances de la classe</returns>
        public static int CombienDeChats()
        {
            return 0;
        }


    }
}
