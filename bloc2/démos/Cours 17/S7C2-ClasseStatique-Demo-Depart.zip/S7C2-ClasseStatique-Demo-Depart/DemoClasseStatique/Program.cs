﻿using System;

namespace DemoClasseStatique
{
    class Program
    {
        static void Main(string[] args)
        {


            float centimetre = 10;

            //Appel de la méthde de la classe sans devoir passé par un objet du type de la classe ConvertisseursUnites.
            
            //Console.WriteLine($"{centimetre} centimètre(s) = {pouces} pouce(s)");

            
            //Console.WriteLine($"{pouces} pouce(s) = {centimetre} centimètre(s)");


            // Créer un premier chat


            //Appel de la méthode static de la classe Chat pour obtenir le nombre d'instances.


            // Créer un deuxième chat
      

            //Appel de la méthode static de la classe Chat pour obtenir le nombre d'instances.


        }
    }
}
