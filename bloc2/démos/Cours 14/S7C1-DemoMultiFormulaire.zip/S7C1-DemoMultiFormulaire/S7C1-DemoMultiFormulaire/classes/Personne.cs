﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S7C1_DemoMultiFormulaire.classes

{
    public class Personne
    {
		private string _nom;

	
		public string Nom
		{
			get { return _nom; }
			private set { _nom = value; }
		}

		private string _prenom;

		public string Prenom
		{
			get { return _prenom; }
			private set { _prenom = value; }
		}

       

        public Personne(string nom, string prenom)
        {
            Nom = nom;
            Prenom = prenom;
        }

        public override string ToString()
        {
            return $"{Nom}, {Prenom}";
        }

	

	}
}
