﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;

namespace S8C2_Demo_SurchargeOperateurs
{
    /// <summary>
    /// Classe représentant une fraction.
    /// </summary>
    public class Fraction
    {

        /* Notez l'absence de section pour les attributs; voir la section sur les propriétés */

        #region PROPRIÉTÉS

        /*
		 * Utilisation de propriétés automatiques.
		 * Les attributs sont générés lors de la compilation et sont cachés.
		 * Entrez "propfull" et faire TAB + TAB pour générer le code automatiquement.
		 */

        /// <summary>
        /// Numérateur de la fraction.
        /// </summary>
        public int Numerateur { get; set; }

        /// <summary>
        /// Dénominateur de la fraction.
        /// </summary>
        public int Denominateur { get; set; }


        /// <summary>
        /// Permet d'obtenir la représentation décimale de la fraction.
        /// </summary>
        public float Decimal
        {
            get
            {
                // Division décimale.
                return this.Numerateur / (float)this.Denominateur;
            }
        }

        #endregion

        #region CONSTRUCTEURS

        /// <summary>
        /// Constructeur paramétré.
        /// </summary>
        /// <param name="numerateur">Numérateur de la fraction.</param>
        /// <param name="denomnateur">Dénominateur de la fraction.</param>
        public Fraction(int numerateur, int denomnateur)
        {
            this.Numerateur = numerateur;
            this.Denominateur = denomnateur;
        }

        #endregion

        #region MÉTHODES

        /// <summary>
        /// Surcharge de l'opérateur de multiplication (*).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>Une nouvelle fraction représentant le produit des deux fractions.</returns>
        public static Fraction operator *(Fraction fractionGauche, Fraction fractionDroite)
        {
            // Produit des numérateurs.
            int produitNumerateur = fractionGauche.Numerateur * fractionDroite.Numerateur;
            // Produit des dénominateurs.
            int produitDenominateur = fractionGauche.Denominateur * fractionDroite.Denominateur;
            // Création d'une nouvelle fraction qui est le produit des deux autres.
            Fraction fractionProduit = new Fraction(produitNumerateur, produitDenominateur);
            // Retour de la nouvelle fraction.
            return fractionProduit;
        }

        /// <summary>
        /// Surcharge de l'opérateur d'addition (+).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>Une nouvelle fraction représentant la somme des deux fractions.</returns>
        public static Fraction operator +(Fraction fractionGauche, Fraction fractionDroite)
        {
            // Produit des dénominateurs.
            int produitDenominateur = fractionGauche.Denominateur * fractionDroite.Denominateur;
            // Produits croisés.
            int prodCroise1 = fractionGauche.Numerateur * fractionDroite.Denominateur;
            int prodCroise2 = fractionDroite.Numerateur * fractionGauche.Denominateur;
            // Création de la nouvelle fraction.
            Fraction fractionSomme = new Fraction(prodCroise1 + prodCroise2, produitDenominateur);
            // Retour de la nouvelle fraction.
            return fractionSomme;
        }

        /// <summary>
        /// Surcharge de l'opérateur d'égalité (==).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>true si les deux fractions sont égales; false, autrement.</returns>
        public static bool operator ==(Fraction fractionGauche, Fraction fractionDroite)
        {
            // Pour gérer le cas où les deux objets reçus en paramètre sont nuls ou bien le même objet.
     
            if (Object.ReferenceEquals(fractionGauche, fractionDroite))
            {
                return true;
            }
            // Pour gérer le cas où un des deux objets reçus en paramètre est nul mais pas les deux (cas précédent).
            // Pour éviter une boucle infinie, on transtype en "Object" avant de comparer.
            //else if ((Object)fractionGauche == null || (Object)fractionDroite == null)
            else if (fractionGauche is null || fractionDroite is null)
            {
                return false;
            }
            else
            {
                // Pour éviter les erreurs d'arrondissement, on n'utilise pas la représentation décimale.
                // Si les fractions sont égales, les produits croisés le sont aussi.
                int prodCroise1 = fractionGauche.Numerateur * fractionDroite.Denominateur;
                int prodCroise2 = fractionDroite.Numerateur * fractionGauche.Denominateur;
                return prodCroise1 == prodCroise2;
            }
        }

        /// <summary>
        /// Surcharge de l'opérateur d'inégalité (!=).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>true si les deux fractions sont différentes; false, autrement.</returns>
        public static bool operator !=(Fraction fractionGauche, Fraction fractionDroite)
        {
            // Retourne l'inverse de l'opérateur d'égalité.
            return !(fractionGauche == fractionDroite);
        }

        /// <summary>
        /// Permet de vérifier si deux objets de type Fraction sont égaux.
        /// </summary>
        /// <param name="obj">Objet de type Fraction à comparer avec l'objet courant</param>
        /// <returns>true si les deux objets sont égaux; false, autrement.</returns>
        /// <remarks>
        /// Redéfinition de la méthode de la classe Object qui compare les références des objets uniquement.
        /// Note: Lorsqu'on définit l'opérateur d'égalité (==), on doit redéfinir la méthode "Equals". 
        /// </remarks>
        public override bool Equals(Object obj)
        {
            // Note : Ne pas lever d'exceptions dans la méthode "Equals".
            // Est-ce que "obj" est nul ou bien d'un autre type que Fraction.
            if (obj is null || obj is not Fraction)
                return false;
            else
                return this == (Fraction)obj;
        }


        /// <summary>
        /// Permet d'obtenir une représentation de la fraction.
        /// </summary>
        /// <returns>Un représentation de la fraction sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return this.Numerateur + "/" + this.Denominateur;
        }

        #endregion

    }
}
