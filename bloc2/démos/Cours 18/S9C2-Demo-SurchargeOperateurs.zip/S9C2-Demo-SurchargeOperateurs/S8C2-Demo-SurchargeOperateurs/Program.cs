﻿using System;

namespace S8C2_Demo_SurchargeOperateurs
{   
    class Program
    {
        static void Main(string[] args)
        {

            Fraction frac1 = new Fraction(2, 3);
            Fraction frac2 = new Fraction(3, 5);

            // Test de l'opérateur de multiplication (*).
            //Console.WriteLine($"Produit de {frac1} et {frac2} = {frac1 * frac2}" );

            // Test de l'opérateur d'addition (+).
            //Console.WriteLine($"Somme de {frac1} et {frac2} = {frac1 + frac2}");

            // Test de l'opérateur d'égalité (==).
            //if (frac1 == frac2)
            //    Console.WriteLine($"La fraction {frac1} est égale à la fraction {frac2}" );
            //else
            //    Console.WriteLine($"La fraction {frac1} est différente de de la fraction {frac2}");

            Fraction frac3 = new Fraction(4, 6);

            // Test de l'opérateur d'inégalité (!=)
            //if (frac1 != frac3)
            //    Console.WriteLine($"La fraction {frac1} est différente de la fraction {frac3}");
            //else
            //    Console.WriteLine($"La fraction {frac1} est égale à la fraction {frac3}");
        }
    }
}
