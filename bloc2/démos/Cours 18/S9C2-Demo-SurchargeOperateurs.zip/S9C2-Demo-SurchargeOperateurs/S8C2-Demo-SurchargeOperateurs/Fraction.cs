﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ObjectiveC;
using System.Text;

namespace S8C2_Demo_SurchargeOperateurs
{
    /// <summary>
    /// Classe représentant une fraction.
    /// </summary>
    public class Fraction
    {

        /* Notez l'absence de section pour les attributs; voir la section sur les propriétés */

        #region PROPRIÉTÉS

        /*
		 * Utilisation de propriétés automatiques.
		 * Les attributs sont générés lors de la compilation et sont cachés.
		 * Entrez "propfull" et faire TAB + TAB pour générer le code automatiquement.
		 */

        /// <summary>
        /// Numérateur de la fraction.
        /// </summary>
        public int Numerateur { get; set; }

        /// <summary>
        /// Dénominateur de la fraction.
        /// </summary>
        public int Denominateur { get; set; }


        /// <summary>
        /// Permet d'obtenir la représentation décimale de la fraction.
        /// </summary>
        public float Decimal
        {
            get
            {
                // Division décimale.
                return this.Numerateur / (float)this.Denominateur;
            }
        }

        #endregion

        #region CONSTRUCTEURS

        /// <summary>
        /// Constructeur paramétré.
        /// </summary>
        /// <param name="numerateur">Numérateur de la fraction.</param>
        /// <param name="denomnateur">Dénominateur de la fraction.</param>
        public Fraction(int numerateur, int denomnateur)
        {
            this.Numerateur = numerateur;
            this.Denominateur = denomnateur;
        }

        #endregion

        #region MÉTHODES

        /// <summary>
        /// Surcharge de l'opérateur de multiplication (*).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>Une nouvelle fraction représentant le produit des deux fractions.</returns>

        // TODO : Implémenter la surcharge de l'opérateur *




        /// <summary>
        /// Surcharge de l'opérateur d'addition (+).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>Une nouvelle fraction représentant la somme des deux fractions.</returns>

        // TODO : Implémenter la surcharge de l'opérateur +

        /// <summary>
        /// Surcharge de l'opérateur d'égalité (==).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>true si les deux fractions sont égales; false, autrement.</returns>

        // TODO : Implémenter la surcharge de l'opérateur ==

        /// <summary>
        /// Surcharge de l'opérateur d'inégalité (!=).
        /// </summary>
        /// <param name="fractionGauche">Fraction à gauche de l'opérateur.</param>
        /// <param name="fractionDroite">Fraction à droite de l'opérateur.</param>
        /// <returns>true si les deux fractions sont différentes; false, autrement.</returns>

        // TODO : Implémenter la surcharge de l'opérateur !=

        /// <summary>
        /// Permet de vérifier si deux objets de type Fraction sont égaux.
        /// </summary>
        /// <param name="obj">Objet de type Fraction à comparer avec l'objet courant</param>
        /// <returns>true si les deux objets sont égaux; false, autrement.</returns>
        /// <remarks>
        /// Redéfinition de la méthode de la classe Object qui compare les références des objets uniquement.
        /// Note: Lorsqu'on définit l'opérateur d'égalité (==), on doit redéfinir la méthode "Equals". 
        /// </remarks>

        // TODO : Redéfinir la méthode Equals
        



        /// <summary>
        /// Permet d'obtenir une représentation de la fraction.
        /// </summary>
        /// <returns>Un représentation de la fraction sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return this.Numerateur + "/" + this.Denominateur;
        }

        #endregion

    }
}
