﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace DemoCompareTo
{
    public class Employe 
    {
       
        /// <summary>
        /// Nom complet de l'employé.
        /// </summary>
        private String _nom;

        /// <summary>
        /// Âge de l'employé.
        /// </summary>
        private byte _age;

        /// <summary>
        /// Salaire hebdomadaire de l'employé.
        /// </summary>
        private float _salaireHebdo;



        /// <summary>
        /// Obtient ou définit le nom complet de l'employé.
        /// </summary>
        public String Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        /// <summary>
        /// Obtient ou définit l'âge de l'employé.
        /// </summary>
        public byte Age
        {
            get { return _age; }
            set { _age = value; }
        }

        /// <summary>
        /// Salaire hebdomadaire de l'employé.
        /// </summary>
        public float SalaireHebdo
        {
            get { return _salaireHebdo; }
            set { _salaireHebdo = value; }
        }

       


        /// <summary>
        /// Constructeur paramétré pour un employé.
        /// </summary>
        /// <param name="nom">Nom de l'employé.</param>
        /// <param name="age">Âge de l'employé.</param>
        /// <param name="salaireHebdo">Salaire hebdomadaire de l'employé.</param>
        /// <param name="sexe">Sexe de l'employé.</param>
        public Employe(String nom, byte age, float salaireHebdo)
        {
            Nom = nom;
            Age = age;
            SalaireHebdo = salaireHebdo;
         
        }

     

        /// <summary>
        /// Permet d'obtenir une représentation de l'employé.
        /// </summary>
        /// <returns>Un représentation de l'employé sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return $"Nom : {Nom,-20} Âge : {Age,2} Salaire : {SalaireHebdo:C2}";
        }

        
    }
}
