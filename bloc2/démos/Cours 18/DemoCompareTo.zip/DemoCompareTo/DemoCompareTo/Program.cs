﻿namespace DemoCompareTo
{
    internal class Program
    {
        static void Main(string[] args)
        {
     
            List<Employe> employes = new List<Employe>();

            employes.Add(new Employe("Martin", 45, 1200));
            employes.Add(new Employe("Julie", 22, 850));
            employes.Add(new Employe("André", 30, 950));
            employes.Add(new Employe("Sophie", 22, 1100));
            employes.Add(new Employe("Éric", 30, 1000));
            employes.Add(new Employe("Eric", 30, 900));

            Console.WriteLine(new string('-', 20));
            Console.WriteLine("LISTE AVANT LE TRI");
            Console.WriteLine(new string('-', 20));
            AfficherEmployes(employes);

            

            Console.ReadKey();
        }

        /// <summary>
        /// Affiche tous les employés d'une liste.
        /// </summary>
        /// <param name="employes">Liste des employés à afficher.</param>
        static void AfficherEmployes(List<Employe> employes)
        {
            foreach (Employe employe in employes)
            {
                Console.WriteLine(employe);
            }
        }
    }
}
