using System;
using Xunit;
using ExempleTestsUnitaires;

namespace CompteBancaireTests
{
    public class CompteBancaireTests
    {
        [Fact]
        public void SetSolde_Devrait_Lancer_ArgumentOutOfRangeException_Quand_Solde_Inferieur_A_0()
        {

            //Arrange Act et Assert
            //Test solde n�gatif
            Assert.Throws<ArgumentOutOfRangeException>(() => new CompteBancaire("Martin", -10));

        }

        [Fact]
        public void Retirer_Devrait_Diminuer_Solde_Quand_Solde_Plus_Grand_Que_MontantRetire()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 100);

            decimal montantRetirer = 50m;

            decimal resultatAttendu = 50m;

            //Act
            compte.Retirer(montantRetirer);

            //Assert
            Assert.Equal(resultatAttendu, compte.Solde);
        }

        [Fact]
        public void Retirer_Devrait_Augmenter_MargeDeCredit_Quand_Solde_0()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 0);

            decimal montantRetirer = 50m;

            decimal resultatMargeDeCredit = 50m;

            //Act
            compte.Retirer(montantRetirer);

            //Assert

            //V�rifie le marge de cr�dit
            Assert.Equal(resultatMargeDeCredit, compte.MargeCredit);

        }

        [Fact]
        public void Retirer_Devrait_Ajuster_Solde_Et_MargeDeCredit_Quand_MontantRetirer_Superieur_A_Solde()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 25);

            decimal montantRetirer = 50m;

            decimal resultatSoldeAttendu = 0m;
            decimal resultatMargeDeCredit = 25m;

            //Act
            compte.Retirer(montantRetirer);

            //Assert

            //V�rifie le solde
            Assert.Equal(resultatSoldeAttendu, compte.Solde);

            //V�rifie le marge de cr�dit
            Assert.Equal(resultatMargeDeCredit, compte.MargeCredit);
        }

        [Fact]
        public void Set_NomPro_Devrait_Lancer_ArgumentNullException_Quand_Null()
        {
            //Arrange
            //Compte instancier avec null
            CompteBancaire compte = new CompteBancaire("Martin", 100);


            //Act et Assert
            //Test si null
            Assert.Throws<ArgumentNullException>(() => compte.Nom = null);



        }

        [Fact]
        public void Set_NomPro_Devrait_Lancer_ArgumentException_Quand_Vide()
        {
            //Arrange
            //Compte instancier avec null
            CompteBancaire compte = new CompteBancaire("Martin", 100);


            //Act et Assert
            //Test si null
            Assert.Throws<ArgumentException>(() => compte.Nom = "");



        }

        [Fact]
        public void Depot_Devrait_Ajouter_Montant_Au_Solde()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 100);

            decimal montantDepot = 50m;

            decimal resultatAttendu = 150m;

            //Act
            compte.Deposer(montantDepot);

            //Assert
            Assert.Equal(resultatAttendu, compte.Solde);

        }

        [Fact]
        public void Depot_Devrait_Lancer_ArgumentOutOfRangeException_Quand_Montant_Inferieur_Ou_Egal_A_0()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 100);

            decimal montantDepot = -50m;

            //Act et Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => compte.Deposer(montantDepot));
        }

        public void Depot_Ne_Devrait_Pas_Augmenter_Solde_Quand_MargeDeCredit_PlusGrand_MontantDepose()
        {
            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 0);
            compte.Retirer(100m);
            decimal montantDepot = 50m;

            decimal resultatSoldeAttendu = 0m;

            //Act
            compte.Deposer(montantDepot);

            //Assert
            Assert.Equal(resultatSoldeAttendu, compte.Solde);

        }

        [Fact]
        public void Depot_Devrait_Ajuster_Sode_Et_MargeCredit_Quand_MargeDeCredit_PlusPetite_Que_MontantDepose()
        {

            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 0);
            compte.Retirer(50m);
            decimal montantDepot = 100m;

            decimal resultatSoldeAttendu = 50m;
            decimal resultatMargeCreditAttendu = 0m;

            //Act
            compte.Deposer(montantDepot);

            //Assert
            //V�rifie le solde
            Assert.Equal(resultatSoldeAttendu, compte.Solde);

            //V�rifie la marge de cr�dit
            Assert.Equal(resultatMargeCreditAttendu, compte.MargeCredit);
        }

        [Fact]
        public void ChargerFrais_Devrait_Lancer_ArgumentOutOfRangeException_Frais_Inferieur_A_0()
        {
            CompteBancaire compte = new CompteBancaire("Martin", 100);
            //Arrange Act et Assert
            //Test frais n�gatif
            Assert.Throws<ArgumentOutOfRangeException>(() => compte.ChargerFrais(-5));

        }

        [Fact]
        public void ChargerFrais_Devrait_Retirer_Frais()
        {

            //Arrange
            CompteBancaire compte = new CompteBancaire("Martin", 100);

            decimal resultatSoldeAttendu = 95;

            //Act
            compte.ChargerFrais(5);

            //Assert
            Assert.Equal(resultatSoldeAttendu, compte.Solde);




        }
    }
}
