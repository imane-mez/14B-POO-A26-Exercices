﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExempleTestsUnitaires
{
    /// <summary>
    /// Classe représentant un compte bancaire avec une marge de crédit (version 1). Le solde du
    /// compte ne peut pas être négatif.
    /// </summary>
    public class CompteBancaire
    {

        /// <summary>
        /// Limite de la marge de crédit.
        /// </summary>
        private const decimal LIMIT_MARGE_CREDIT = 5000;


        // Note: On ajoute le préfixe "_" (soulignement) aux noms d'attributs pour les distinguer des accesseurs.

        /// <summary>
        /// Nom du propriétaire du compte.
        /// </summary>
        private String _nom;

        /// <summary>
        /// Solde du compte.
        /// <remarks>Ne peut pas être négatif.</remarks>
        /// </summary>
        private decimal _solde;

        /// <summary>
        /// Montant sur le marge de crédit associée au compte.
        /// </summary>
        private decimal _margeCredit;

       


        // Note : Dans les accesseurs et seulement ici, on utilise toujours les attributs directement pour éviter les références circulaires.

        /// <summary>
        /// Nom du propriétaire du compte.
        /// </summary>
        public String Nom
        {
            get { return _nom; }
            set
            {
              
                _nom = value;
            }

        }



        /// <summary>
        /// Solde du compte.
        /// Ne peut pas être négatif.
        /// </summary>
        public decimal Solde
        {
            get { return _solde; }

            // Accesseur en écriture privé.
            private set
            {
                
                _solde = value;
            }
        }

        /// <summary>
        /// Montant sur le marge de crédit associée au compte.
        /// Ne doit pas dépasser la limite de crédit.
        /// </summary>
        public decimal MargeCredit
        {
            get { return _margeCredit; }

            // Accesseur en écriture privé.
            private set { _margeCredit = value; }
        }

      

        

        /// <summary>
        /// Constructeur avec tous les paramètres optionnels.
        /// Pour ouvrir un compte avec un montant sur la marge de crédit, il faut fournir un solde négatif.
        /// </summary>
        /// <param name="nomProp">Nom du propriétaire du compte.</param>
        /// <param name="solde">Solde du compte.</param>
        public CompteBancaire(String nomProp, decimal solde = 0)
        {


            // On commence par initialiser à zéro la marge de crédit car elle sera peut être modifiée
            // lors de l'affectation du solde par l'entremise de l'accesseur en écriture (voir ci-dessous).
            MargeCredit = 0;

            // Utilisation des accesseurs en écriture au lieu d'utiliser directement les attributs.
            Nom = nomProp;
            Solde = solde;
        }

       

        

        /// <summary>
        /// Permet de déposer un montant dans le compte.
        /// La marge de crédit est remboursée si elle n'est pas à zéro.
        /// </summary>
        /// <param name="montant">Montant à déposer (plus grand que zéro)</param>
        public void Deposer(decimal montant)
        {

            throw new NotImplementedException();

           

        }

        /// <summary>
        /// Permet de retirer un montant dans le compte.
        /// La marge de crédit est utilisée si nécessaire et possible.
        /// </summary>
        /// <param name="montant">Montant à retirer (plus grand que zéro)</param>
        public void Retirer(decimal montant)
        {

            throw new NotImplementedException();


        }
                                   

        /// <summary>
        /// Permet de charger des frais de gestion de compte.
        /// </summary>
        /// <param name="frais">Montant des frais chargés</param>
        public void ChargerFrais(decimal frais)
        {
            throw new NotImplementedException();
        }

      
       
    }
}
