﻿using System;

namespace ExempleTestsUnitaires
{
    class Program
    {
        static void Main(string[] args)
        {
            // Pour agrandir la taille de la console.
            Console.SetWindowSize(80, Console.LargestWindowHeight - 5);

            // Création d'un compte bancaire avec le constructeur prenant en paramètre le nom du propriétaire seulement.
            CompteBancaire cb1 = new CompteBancaire("Véronique");

            // Affichage du compte bancaire.
            Console.WriteLine("Compte créé :");
            Console.WriteLine(cb1);


            // Dépôt.
            cb1.Deposer(2500);

            Console.WriteLine("\nCompte après dépôt de 2500 $ :");
            Console.WriteLine(cb1);

            // Retrait.
            cb1.Retirer(2000);

            Console.WriteLine("\nCompte après retrait de 2000 $ :");
            Console.WriteLine(cb1);

            // Retrait.
            cb1.Retirer(1500);

            Console.WriteLine("\nCompte après retrait de 1500 $ :");
            Console.WriteLine(cb1);

            // Retrait.
            cb1.Retirer(5000);

            Console.WriteLine("\nCompte après retrait de 5000 $ :");
            Console.WriteLine(cb1);

            // Dépôt.
            cb1.Deposer(4000);

            Console.WriteLine("\nCompte après dépôt de 4000 $ :");
            Console.WriteLine(cb1);

            // Frais.
            cb1.ChargerFrais(5);

            Console.WriteLine("\nCompte après frais de 5 $ :");
            Console.WriteLine(cb1);

            // Dépôt.
            cb1.Deposer(1500);

            Console.WriteLine("\nCompte après dépôt de 1500 $ :");
            Console.WriteLine(cb1);


            // Création d'un nouveau compte avec un solde négatif dès la création.
            // Le solde négatif sera transféré sur la marge de crédit.
            CompteBancaire cb2 = new CompteBancaire("Pierre", -1500);

            // Affichage du nouveau compte bancaire.
            Console.WriteLine("\nNouveau compte crée avec un solde négatif :");
            Console.WriteLine(cb2);

            // Saut de ligne.
            Console.WriteLine();
        }

        
    }
}
