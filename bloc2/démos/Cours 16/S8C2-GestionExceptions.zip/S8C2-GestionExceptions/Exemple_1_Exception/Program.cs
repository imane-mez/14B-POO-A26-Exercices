﻿using System;

namespace Exemple_1_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(120, Console.LargestWindowHeight - 5);

            Console.WriteLine("=== DÉMONSTRATION : Division sécurisée ===");

            int a = 30;
            Console.Write("Entrez un diviseur : ");

           
            int b = int.Parse(Console.ReadLine());
            int resultat = a / b;
            Console.WriteLine($"Résultat : {a} / {b} = {resultat}");
          
            Console.WriteLine("Fin du programme. Merci d’avoir participé !");
            
        }
    }
}
