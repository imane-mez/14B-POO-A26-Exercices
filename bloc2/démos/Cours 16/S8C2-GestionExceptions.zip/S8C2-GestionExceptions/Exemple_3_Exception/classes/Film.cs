﻿


using Exemple_3_Exception.enums;
using System;

namespace Exemple_3_Exception.classes
{
    /// <summary>
    /// Classe représentant un film.
    /// </summary>
    public class Film
    {

        /// <summary>
        /// Valeur minimal pour l'année
        /// </summary>
        public const ushort ANNEE_MIN = 1500;

        /// <summary>
        /// Valeur minimal pour le nombre de caractères du titre
        /// </summary>
        public const byte TITRE_NB_CARACT_MIN = 3;


        private Guid _id;
        private string _titre;
        private ushort _annee;
        private CategorieFilm _categorie;


        /// <summary>
        /// Obtient ou définit l'identifiant unique du film
        /// </summary>
        public Guid Id
        {
            get => _id;  // équivalent à { return _id; }
            set
            {
              
                _id = value;
            }
        }




        /// <summary>
        /// Obtient ou définit le titre du film.
        /// </summary>
        public string Titre
        {
            get => _titre; 
            set 
            {
               
                _titre = value.Trim(); 
            }
        }

        /// <summary>
        /// Obtient ou définit l'année de sortie du film.
        /// </summary>
        public ushort Annee
        {
            get => _annee; 
            set 
            {
                _annee = value; 
            }
        }



        /// <summary>
        /// Catégorie du film.
        /// </summary>
        public CategorieFilm Categorie
        {
            get => _categorie;
            set
            {
                _categorie = value;
            }
        }


        /// <summary>
        /// Constructeur paramétré acceptant le titre et l'année du film.
        /// </summary>
        /// <param name="titre">Titre du film.</param>
        /// <param name="annee">Année de sortie du film.</param>
        public Film(string titre, ushort annee, CategorieFilm categorie)
        {
            Titre = titre;
            Annee = annee;
            Categorie = categorie;
        }


        /// <summary>
        /// Permet d'obtenir une représentation du film.
        /// </summary>
        /// <returns>Un représentation du film sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return $"{Titre} ({Annee}, {Categorie})";
        }

 
    }
}