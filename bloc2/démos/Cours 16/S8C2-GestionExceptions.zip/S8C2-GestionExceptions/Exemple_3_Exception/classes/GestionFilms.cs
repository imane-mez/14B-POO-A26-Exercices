﻿using System;
using System.Collections.Generic;

namespace Exemple_3_Exception.classes
{
    class GestionFilms
    {
        private List<Film> _films;

        public List<Film> Films
        {
            get { return _films; }
            private set { _films = value; }
        }

        public GestionFilms()
        {
            Films = new List<Film>();
        }

        /// <summary>
        /// Permet de vérifier si un film existe dans la liste
        /// </summary>
        /// <param name="film">Film à recherche dans la liste</param>
        /// <returns>Vrai si le film existe, faux sinon</returns>
        public bool Existe(Film film)
        {
            
            foreach (Film f in Films)
            {
                if (film.Titre.ToLower().Trim() == f.Titre.ToLower().Trim() && film.Annee == f.Annee)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Permet d'ajouter un film à la liste
        /// </summary>
        /// <param name="film">Film à ajouter à la liste</param>
        /// <returns>Vrai si le film a été ajouté, faux sinon.</returns>
        public bool AjouterFilm(Film film)          
        {
           
            if (!Existe(film))
            {
                Films.Add(film);
                return true;
            }

            return false;
                
        }
        /// <summary>
        /// Permet de supprimer un film de la liste
        /// </summary>
        /// <param name="pFilm">Film à supprimer de la liste</param>
        /// <returns>Vrai si le film a été retiré, faux sinon.</returns>
        public bool SupprimerFilm(Film film)
        {
            return Films.Remove(film);
        }

    }
}
