﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Exemple_3_Exception
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
