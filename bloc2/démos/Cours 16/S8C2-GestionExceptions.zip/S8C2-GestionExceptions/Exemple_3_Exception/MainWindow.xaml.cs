﻿using Exemple_3_Exception.classes;
using Exemple_3_Exception.enums;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Exemple_3_Exception
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Permet la gestion des films
        private GestionFilms _gestionFilms;


        /// <summary>
        /// Constructeur de la fenêtre principale.
        /// Initialise les composants graphiques et la gestion des films.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            _gestionFilms = new GestionFilms();
        }

        /// <summary>
        /// Événement déclenché lorsque la fenêtre est chargée.
        /// Initialise le contenu du formulaire.
        /// </summary>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();

        }

        /// <summary>
        /// Initialise la liste déroulante des catégories de films à partir de l’énumération <see cref="CategorieFilm"/>.
        /// </summary>
        private void InitialiserListeCategorie()
        {
            string[] categories = Enum.GetNames(typeof(CategorieFilm));

            foreach(string categorie in categories)
            {
                cboCategories.Items.Add(categorie);
            }
        }

        /// <summary>
        /// Réinitialise les champs du formulaire à leur état initial.
        /// Vide les zones de texte, désélectionne la catégorie et recharge les listes.
        /// </summary>
        private void InitialiserFormulaire()
        {
            txtTitre.Clear();
            txtAnnee.Clear();
            cboCategories.SelectedIndex = -1;
            InitialiserListeCategorie();
            InitialiserListeFilms();
        }


        /// <summary>
        /// Recharge la liste des films à partir de la collection gérée par GestionFilms/>.
        /// </summary>

        private void InitialiserListeFilms()
        {
            lstFilms.Items.Clear();
            foreach (Film film in _gestionFilms.Films)
            {
                lstFilms.Items.Add(film);
            }
        }

        /// <summary>
        /// Événement appelé lors du clic sur le bouton « Ajouter ».
        /// Valide les informations saisies, crée un nouvel objet Film et l’ajoute à la liste.
        /// </summary>
        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
           
            if (ValiderFilm())
            {
                Film nouveauFilm = new Film(txtTitre.Text, ushort.Parse(txtAnnee.Text), (CategorieFilm) cboCategories.SelectedIndex);

                if (!_gestionFilms.Existe(nouveauFilm))
                {
                    if (_gestionFilms.AjouterFilm(nouveauFilm))
                    {
                        MessageBox.Show("Le film a été ajouté avec succès!", "Ajout d'un nouveau film");
                        InitialiserFormulaire();
                    }

                    else
                        MessageBox.Show("Une erreur s'est produit. Impossible d'ajouter ce film à la liste.", "Ajout d'un nouveau film");


                }
                else
                    MessageBox.Show("Ce film existe déjà dans la liste.", "Ajout d'un nouveau film");

            }
           


        }

        /// <summary>
        /// Valide les champs du formulaire avant la création d’un film.
        /// Vérifie le titre, l’année et la catégorie sélectionnée.
        /// </summary>
        /// <returns>
        /// True si les données sont valides, false sinon.
        /// </returns>
        private bool ValiderFilm()
        {
            string message = "";

            if (string.IsNullOrWhiteSpace(txtTitre.Text) || txtTitre.Text.Length < 3)
                message += $"- Le titre du film doit contenir au moins {Film.TITRE_NB_CARACT_MIN} caractères.\n";

            ushort annee;
            if (!ushort.TryParse(txtAnnee.Text, out annee) || annee < Film.ANNEE_MIN || annee > DateTime.Now.Year)
                message += $"- L'anné doit être une valeur numérique comprise entre {Film.ANNEE_MIN} et {DateTime.Now.Year}\n";

            if (cboCategories.SelectedIndex == -1)
                message += $"- Vous devez sélectionner une catégorie";

            if (message != "") 
            {
                MessageBox.Show($"Veuillez corriger les erreurs suivantes : \n\n{message}", "Validation d'un film");
                return false;
            }

            return true;
        }


        /// <summary>
        /// Événement appelé lors du clic sur le bouton « Supprimer ».
        /// Supprime le film sélectionné de la liste s’il existe.
        /// </summary>
        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            
            if (lstFilms.SelectedItem == null)
                MessageBox.Show("Vous devez sélectionner un film dans la liste.", "Suppression d'un film");
            else
            {
                Film film = (Film)lstFilms.SelectedItem;

                if (_gestionFilms.SupprimerFilm(film))
                {
                    MessageBox.Show("Le film a été supprimer avec succès!", "Suppression d'un film");
                    InitialiserFormulaire();
                }
                else
                    MessageBox.Show("Une erreur s'est produit. Impossible de supprimer ce film de la liste.", "Suppression d'un film");

            }
           

        }

        /// <summary>
        /// Événement appelé lors du clic sur le bouton « Quitter ».
        /// Ferme la fenêtre principale de l’application.
        /// </summary>
        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Événement déclenché lorsque la sélection dans la liste des films change.
        /// Met à jour les champs du formulaire avec les informations du film sélectionné.
        /// </summary>
        private void lstFilms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstFilms.SelectedItem != null)
            {
                Film film = (Film)lstFilms.SelectedItem;

                txtTitre.Text = film.Titre;
                txtAnnee.Text = film.Annee.ToString();
                cboCategories.SelectedIndex = (int) film.Categorie;
            }
        }

        /// <summary>
        /// Événement appelé lors du clic sur le bouton « Nouveau ».
        /// Réinitialise le formulaire pour permettre la saisie d’un nouveau film.
        /// </summary>
        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
        }
    }
}