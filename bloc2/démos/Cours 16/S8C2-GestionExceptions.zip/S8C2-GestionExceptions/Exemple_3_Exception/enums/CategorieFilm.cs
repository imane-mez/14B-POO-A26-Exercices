﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple_3_Exception.enums
{
    public enum CategorieFilm
    {
        Action,
        Comedie,
        Drame,
        Horreur,
        ScienceFiction,
        Romance,
        Aventure,
        Policier,
        Animation,
        Documentaire
    }
}
