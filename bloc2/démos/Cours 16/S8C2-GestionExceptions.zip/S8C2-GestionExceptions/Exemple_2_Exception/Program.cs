﻿using System;
using System.IO;

namespace Exemple_2_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
           

            Console.Write(
                "Entrez le nom du fichier à ouvrir (les bons noms sont \"data1.txt\" ou bien \"data2.txt\") : ");
            String nomFichier = Console.ReadLine();

            // Déclaration du flux de lecture à l'extérieur du bloc "try" pour pouvoir l'utiliser
            // dans le bloc "finally" ci-dessous.
            // La variable doit aussi être initialisée.
            StreamReader fluxLecture = null;

            string cheminFichier = AppContext.BaseDirectory + @"data\" + nomFichier;

            // Tentative d'ouverture d'un fichier en lecture.
            fluxLecture = new StreamReader(cheminFichier);

            // S'il n'y pas d'erreur, "fluxLecture" n'est pas à "null" et on continue le traitement; autrement, on ne fait rien.
            if (fluxLecture != null)
            {
                
                // Lecture de la seule ligne du fichier.
                String ligne = fluxLecture.ReadToEnd();

                String[] lesNbEnChaine = ligne.Split(',');

                // Affichage des entiers.
                int nb;
                for (int i = 0; i < lesNbEnChaine.Length; i++)
                {
                    // Lève une exception si ce n'est pas un entier valide.
                    nb = int.Parse(lesNbEnChaine[i].Trim());
                    Console.WriteLine(nb);
                }
              
                   
                fluxLecture.Close();
                
               
            }

            Console.Write("Fin du programme");
            Console.ReadKey();
        }
    }
}
