﻿using System;

namespace Exemple_1_Exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.SetWindowSize(120, Console.LargestWindowHeight - 5);

            Console.WriteLine("=== DÉMONSTRATION : Division sécurisée ===");

            int a = 30;
            Console.Write("Entrez un diviseur : ");

            try
            {
                int b = int.Parse(Console.ReadLine());
                int resultat = a / b;
                Console.WriteLine($"Résultat : {a} / {b} = {resultat}");
            }
            catch (FormatException)
            {
                Console.WriteLine("Erreur : vous devez entrer un nombre entier.");
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Erreur : division par zéro interdite !");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur inattendue : {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Fin du programme. Merci d’avoir participé !");
            }
        }
    }
}
