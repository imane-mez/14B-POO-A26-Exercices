﻿using System;
using System.Collections.Generic;

namespace Exemple_3_Exception.classes
{
    /// <summary>
    /// Classe permettant la gestion de films
    /// </summary>
    class GestionFilms
    {
        private List<Film> _films;

        /// <summary>
        /// Obtiento ou définit la liste des films
        /// </summary>
        public List<Film> Films
        {
            get { return _films; }
            private set { _films = value; }
        }

        /// <summary>
        /// Constructeur de la classe Film qui initialise une lise de films vide.
        /// </summary>
        public GestionFilms()
        {
            Films = new List<Film>();
        }

        /// <summary>
        /// Permet de vérifier si un film existe dans la liste
        /// </summary>
        /// <param name="film">Film à recherche dans la liste</param>
        /// <returns>Vrai si le film existe, faux sinon</returns>
        /// <exception cref="ArgumentNullException">Lancer lorsque pfilm est null</exception>
        public bool Existe(Film film)
        {
            if (film == null)
                throw new ArgumentNullException(nameof(film), "Le film ne peut pas être null");

            foreach (Film f in Films)
            {
                if (f.Titre.ToLower().Trim() == film.Titre.ToLower().Trim() && f.Annee == film.Annee)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Permet d'ajouter un film à la liste
        /// </summary>
        /// <param name="film">Film à ajouter à la liste</param>
        /// <returns>Vrai si le film a été ajouté, faux sinon.</returns>
        /// <exception cref="ArgumentNullException">Lancer lorsque pfilm est null</exception>
        /// <exception cref="InvalidOperationException">Lancer quand le film existe déjà dans la liste</exception>
        public void AjouterFilm(Film film)          
        {
            if (film == null)
                throw new ArgumentNullException(nameof(film), "Le film ne peut pas être null");

            if (Existe(film))
                throw new InvalidOperationException("Impossible d'ajouter ce film, car celui-ci existe déja dans la liste");
           
                Films.Add(film);
        }

        /// <summary>
        /// Permet de supprimer un film de la liste
        /// </summary>
        /// <param name="film">Film à supprimer de la liste</param>
        /// <returns>Vrai si le film a été retiré, faux sinon.</returns>
        /// <exception cref="ArgumentNullException">Lancer lorsque pfilm est null</exception>
        public bool SupprimerFilm(Film film)
        {
            if (film == null)
                throw new ArgumentNullException(nameof(film), "Le film ne peut pas être null");


            return Films.Remove(film);
            
  
        }

    }
}
