﻿


using Exemple_3_Exception.enums;
using System;

namespace Exemple_3_Exception.classes
{
    /// <summary>
    /// Classe représentant un film.
    /// </summary>
    public class Film
    {

        /// <summary>
        /// Valeur minimal pour l'année
        /// </summary>
        public const ushort ANNEE_MIN = 1500;

        /// <summary>
        /// Valeur minimal pour le nombre de caractères du titre
        /// </summary>
        public const byte TITRE_NB_CARACT_MIN = 3;


        private Guid _id;
        private string _titre;
        private ushort _annee;
        private CategorieFilm _categorie;


        /// <summary>
        /// Obtient ou définit l'identifiant unique du film
        /// </summary>
        /// <exception cref="ArgumentException">Lancée lorsque la valeur assignée est <see cref="Guid.Empty"/>.</exception>
        public Guid Id
        {
            get => _id;  // équivalent à { return _id; }
            set
            {
                if (value == Guid.Empty)
                    throw new ArgumentException("L'identifiant ne peut pas être vide.", nameof(Id));

                _id = value;
            }
        }




        /// <summary>
        /// Obtient ou définit le titre du film.
        /// </summary>
        /// <exception cref="ArgumentNullException">Lancée lorsque le titre est nul</exception>
        /// <exception cref="ArgumentException">Lancé lorsque le titre est vide ou ne contient que des espaces</exception>
        /// <exception cref="ArgumentOutOfRangeException">Lancée lorsque le titre est inférieure à <see cref="TITRE_NB_CARACT_MIN">TITRE_MIN_NB_CARAC</see>/></exception>
        public string Titre
        {
            get => _titre; 
            set 
            {
                if (value == null)
                    throw new ArgumentNullException(nameof(Titre), "Le titre du film ne doit pas être nul.");

                value = value.Trim();

                if (value.Length == 0)
                    throw new ArgumentException("Le titre du film ne doit pas être vide ou ne contenir que des espaces.", nameof(Titre));


                if (value.Trim().Length < TITRE_NB_CARACT_MIN)
                    throw new ArgumentOutOfRangeException(nameof(Titre), $"Le titre doit contenir au moins {TITRE_NB_CARACT_MIN} caractères.");

                _titre = value.Trim(); 
            }
        }

        /// <summary>
        /// Obtient ou définit l'année de sortie du film.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Lancée lorsque l'année est inférieur à <see cref="ANNEE_MIN">ANNE_MIN_VAL</see>/> et supérieure à l'année courante/></exception>>
        public ushort Annee
        {
            get => _annee; 
            set 
            {
                if (value < ANNEE_MIN || value > DateTime.Now.Year)
                    throw new ArgumentOutOfRangeException($"L'année doit être comprise entre { ANNEE_MIN} et {DateTime.Now.Year}.");

                _annee = value; 
            }
        }



        /// <summary>
        /// Catégorie du film.
        /// </summary>
        /// <exception cref="ArgumentOutOfRangeException">Lancée lorsque la catégorie fournie n'est pas une valeur définie de CategorieFilm/>.</exception>
        public CategorieFilm Categorie
        {
            get => _categorie;
            set
            {
                if (!Enum.IsDefined(typeof(CategorieFilm), value))
                    throw new ArgumentOutOfRangeException(nameof(Categorie),"La catégorie fournie n'est pas valide.");

                _categorie = value;
            }
        }


        /// <summary>
        /// Constructeur paramétré acceptant le titre et l'année du film.
        /// </summary>
        /// <param name="titre">Titre du film.</param>
        /// <param name="annee">Année de sortie du film.</param>
        public Film(string titre, ushort annee, CategorieFilm categorie)
        {
            Titre = titre;
            Annee = annee;
            Categorie = categorie;
        }


        /// <summary>
        /// Permet d'obtenir une représentation du film.
        /// </summary>
        /// <returns>Un représentation du film sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return $"{Titre} ({Annee}, {Categorie})";
        }

 
    }
}