﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoListeGenerique
{
   
    class Produit
    {

        private Guid _id;
        private string  _code;
        private string _nom ;
        private decimal _prix;


        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Code
        {
            get { return _code; }
            set { _code = value; }
        }

        public string Nom
        {
            get { return _nom; }
            set { _nom = value; }
        }

        public decimal Prix
        {
            get { return _prix; }
            set { _prix = value; }
        }

        public Produit(Guid id, string code, string nom, decimal prix)
        {
            Id = id;
            Code = code;
            Nom = nom;
            Prix = prix;
        }

        public override string ToString()
        {
            return $"{Code} - {Nom} ({Prix:C2})";
        }
    }
}
