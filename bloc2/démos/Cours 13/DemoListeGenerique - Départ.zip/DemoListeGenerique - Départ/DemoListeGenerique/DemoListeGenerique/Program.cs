﻿namespace DemoListeGenerique
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Déclaration et initialistion de produits
            Produit p1 = new Produit(Guid.NewGuid(), "ELEC-S24-001", "Samsung Galaxy S24 ", 899.99m);
            Produit p2 = new Produit(Guid.NewGuid(), "ELEC-TAB-015", "iPad Air M2", 699.99m);

            //Déclaration et initialisation d'une liste de produits vide


            //Ajout d'un produit à la liste


            //Ajout d'un autre produit à la liste
            // "ELEC-S24-002", "Apple iPhone 16", 969.00m
            


            //Affichage des produits faisant partie de la liste
            

            //Inverser l'ordre de la liste
            

            //Affichage des produits faisant partie de la liste
            


            //Vérification si un produit existe dans la liste
            

            //Création d'un produit identique à p1 et vérifier si ce produit existe dans la liste
            

            //Insertion d'un produit au début s'il n'existe pas dans la liste
            



            //Affichage des produits faisant partie de la liste
            

            //Obtenir la position d'un objet dans la liste
            

            //Retirer un élément à une position spécifique
            

            //Affichage des produits faisant partie de la liste
            

            //Retrait d'un objet avec confirmation
            

            //Affichage des produits faisant partie de la liste
            

            //Effacer le contenu de la liste puis l'afficher
            



            Produit[] tabProduits = new Produit[] { p1, p2 };

            //Ajout de produits à partir d'un tableau
            
            // Affichage des produits
            

            // Manipulation d'une liste d'entiers. Différence Capacity / Count
            List<int> listeEntiers = new List<int>();

            Console.WriteLine($"Capacité de la liste : {listeEntiers.Capacity}.\nNombre d'éléments : {listeEntiers.Count}");
            listeEntiers.Add(0);
            Console.WriteLine($"Capacité de la liste : {listeEntiers.Capacity}.\nNombre d'éléments : {listeEntiers.Count}");

            for (int i = 1; i < 4; i++)
            {
                listeEntiers.Add(i);
            }
            Console.WriteLine($"Capacité de la liste : {listeEntiers.Capacity}.\nNombre d'éléments : {listeEntiers.Count}");

            listeEntiers.Add(5);
            Console.WriteLine($"Capacité de la liste : {listeEntiers.Capacity}.\nNombre d'éléments : {listeEntiers.Count}");
        }

        private static void AfficherProduits(List<Produit> produits)
        {
            Console.WriteLine("\n" + new string('=', 20));    
            Console.WriteLine("Liste des produits");
            Console.WriteLine(new string('=', 20));
            // TODO : Afficher les produits et un message personnalisé si la liste est vide.

        }
    }
}