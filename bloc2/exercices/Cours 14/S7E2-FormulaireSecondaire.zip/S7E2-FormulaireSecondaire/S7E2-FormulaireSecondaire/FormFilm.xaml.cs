﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace S7E1_ListeGenerique
{
    /// <summary>
    /// Fenêtre secondaire permettant d’afficher les détails d’un film sélectionné.
    /// </summary>
    public partial class FormFilm : Window
    {
        // Champ privé pour stocker le film dont on veut afficher les détails.
        private Film _film;

        /// <summary>
        /// Obtient ou définit un filme
        /// </summary>
        /// <remarks>
        /// Le setter est privé, car la fenêtre reçoit le film à afficher uniquement au moment de la création.
        /// la modification d'un film doit se faire uniquement dans le formulaire.
        /// </remarks>
        public Film Film
        {
            get { return _film; }
            private set { _film = value; }
        }

        /// <summary>
        /// Constructeur de la fenêtre FormFilm.
        /// </summary>
        /// <param name="film">Objet Film dont on veut afficher les détails.</param>
        /// <remarks>
        /// La référence du film est reçue en paramètre depuis la fenêtre principale.  
        /// Cette approche permet de partager le même objet entre les deux fenêtres, sans duplication des données.
        /// </remarks>

        public FormFilm(Film film)
        {
            InitializeComponent();

            Film = film;
        }

        /// <summary>
        /// Événement déclenché lorsque la fenêtre est complètement chargée.
        /// </summary>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AfficherDetailsFilm();
        }

        /// <summary>
        /// Affiche les détails du film dans les contrôles de la fenêtre.
        /// </summary>
    
        private void AfficherDetailsFilm()
        {
            // On s'assure que l’objet Film n’est pas nul (sécurité).
            if (Film != null)
            {
                // Affichage des informations du film
                txtTitre.Text = Film.Titre;
                txtAnnee.Text = Film.Annee.ToString();

                foreach (string acteur in Film.Acteurs)
                {
                    lstActeurs.Items.Add(acteur);
                }
            }
        }

        /// <summary>
        /// Événement déclenché lorsque l’utilisateur clique sur le bouton "Fermer".
        /// </summary>
        private void btnFermer_Click(object sender, RoutedEventArgs e)
        { 
            Close();
        }
    }
}
