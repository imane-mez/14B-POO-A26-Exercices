﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S7E1_ListeGenerique
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        // Déclaration d’un objet de type GestionFilms.
        // Cet objet contiendra la liste de tous les films gérés par l’application.
        private GestionFilms _gestionFilms;


        /// <summary>
        /// Constructeur de la fenêtre principale.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            // Instanciation de l’objet de gestion des films.
            // À ce moment, la liste est vide.
            _gestionFilms = new GestionFilms();
            
        }


        /// <summary>
        /// Événement déclenché lorsque la fenêtre est complètement chargée en mémoire et s'affiche.
        /// </summary>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Création d’une liste d’acteurs (vide au départ).
            List<string> acteurs = new List<string>();

            // Ajout d’acteurs à la liste.
            acteurs.Add("Tom Holland");
            acteurs.Add("Zendaya Colman");

            // Création d’un nouvel objet Film en utilisant le constructeur paramétré.
            Film film = new Film("Spider-man No way home", 2021, acteurs);

            // Variante condensée équivalente (initialisation directe de la liste dans le constructeur).
            // Film film = new Film("Spider-man No way home", 2021, new List<string>() { "Tom Holland", "Zendaya Colman" });

            // Ajout du film créé dans la gestion des films.
            _gestionFilms.AjouterFilm(film);

            // Appel de la méthode pour afficher les films dans la liste visuelle.
            AfficherListeFilms();

        }



        /// <summary>
        /// Affiche la liste des films contenus dans _gestionFilms dans la ListBox lstFilms.
        /// </summary>
        private void AfficherListeFilms()
        {
            // On vide d’abord la liste à l’écran (au cas où elle contiendrait déjà des éléments).
            lstFilms.Items.Clear();

            // On parcourt la liste des films gérés.
            foreach (Film film in _gestionFilms.Films)
            {
                // On ajoute chaque film dans la ListBox.
                // La méthode ToString() du film est utilisée automatiquement pour l’affichage.
                lstFilms.Items.Add(film);
            }
        }


        /// <summary>
        /// Événement déclenché lorsque l’utilisateur clique sur le bouton "Afficher les détails".
        /// </summary>
        private void btnAfficherDetails_Click(object sender, RoutedEventArgs e)
        {
            // Vérifie qu’un film a bien été sélectionné dans la liste.
            if (lstFilms.SelectedItem == null)
            {
                MessageBox.Show("Vous devez sélectionner un film dans la liste.");
            }
            else
            {
                // On récupère le film sélectionné et on le convertit (cast) en type Film.
                Film filmSelect = lstFilms.SelectedItem as Film;

                // Création d’une nouvelle fenêtre de type FormFilm (fenêtre secondaire).
                // On lui envoie en paramètre le film sélectionné afin qu’elle affiche ses détails.
                FormFilm frmFilm = new FormFilm(filmSelect);

                // Affiche la fenêtre de détails de façon modale (bloque la fenêtre principale tant qu’elle est ouverte).
                frmFilm.ShowDialog();
            }
        }
    }
}
