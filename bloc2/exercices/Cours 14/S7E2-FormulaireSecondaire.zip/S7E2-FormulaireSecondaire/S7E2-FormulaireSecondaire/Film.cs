﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Text;

namespace S7E1_ListeGenerique
{
    /// <summary>
    /// Représente un film avec un titre, une année de sortie et une liste d'acteurs.
    /// </summary>
    public class Film
    {
        /// <summary>
        /// Année minimale permise pour un film.
        /// </summary>
        public const ushort ANNEE_MIN = 1500;

        /// <summary>
        /// Valeur utilisée lorsque le titre n’est pas fourni.
        /// </summary>
        public const string VALEUR_NON_FOURNIE = "Non fourni";
                    
        private string _titre;
        private ushort _annee;
        private List<string> _acteurs;

        /// <summary>
        /// Obtient ou définit le titre du film.
        /// </summary>
        /// <remarks>
        /// Si la valeur fournie est vide ou nulle, le titre est remplacé par <see cref="VALEUR_NON_FOURNIE"/>.
        /// Les espaces au début et à la fin du texte sont automatiquement supprimés.
        /// </remarks>
        public string Titre
        {
            get { return _titre; }
            set {
                if (string.IsNullOrWhiteSpace(value))
                    value = VALEUR_NON_FOURNIE;
                _titre = value.Trim(); }
        }

        /// <summary>
        /// Obtient ou définit l’année de sortie du film.
        /// </summary>
        /// <remarks>
        /// Si la valeur est inférieure à <see cref="ANNEE_MIN"/>, elle est remplacée par <see cref="ANNEE_MIN"/>.  
        /// Si la valeur est supérieure à l’année courante, elle est remplacée par l’année actuelle.
        /// </remarks>
        public ushort Annee
        {
            get { return _annee; }
            set {
                if (value < ANNEE_MIN)
                    value = ANNEE_MIN;
                else if (value > DateTime.Now.Year)
                    value = (ushort)DateTime.Now.Year;

                _annee = value; 
            }
        }


        /// <summary>
        /// Obtient ou définit la liste des acteurs.
        /// </summary>
        public List<string> Acteurs
        {
            get { return _acteurs; }
            set { _acteurs = value; }
        }


        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Film"/>.
        /// </summary>
        /// <param name="titre">Titre du film.</param>
        /// <param name="annee">Année de sortie du film.</param>
        /// <param name="acteurs">Liste des acteurs du film.</param>
        
        public Film(string titre, ushort annee, List<string> acteurs)
        {
            Titre = titre;
            Annee = annee;
            Acteurs = acteurs;
        }


        /// <summary>
        /// Retourne une représentation textuelle du film.
        /// </summary>
        /// <returns>
        /// Une chaîne contenant le titre et l’année du film (ex. : Inception (2010)).
        /// </returns>        
        public override string ToString()
        {
            return $"{Titre} ({Annee})";
        }

      
    }

}
