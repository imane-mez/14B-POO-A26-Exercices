﻿using System;
using System.Collections.Generic;
using System.Text;

namespace S7E1_ListeGenerique
{
    class GestionFilms
    {


    
        private List<Film> _films;
  
        public List<Film> Films
        {
            get { return _films; }
            set { _films = value; }
        }
       


      
        public GestionFilms()
        {
            Films = new List<Film>();
        }
      

    
        public Film RechercherFilm(Film pFlim)
        {
            foreach (Film film in Films)
            {
                if (pFlim.Titre.ToLower().Trim() == film.Titre.ToLower().Trim() 
                    && pFlim.Annee == film.Annee)
                    return film;
            }

            return null;
        }

        public bool AjouterFilm(Film pFilm)
        {
            if (RechercherFilm(pFilm) == null)
            {
                Films.Add(pFilm);
                return true;
            }

            return false;

        }

        public bool SupprimerFilm(Film film)
        {

             return  Films.Remove(film);
           
        }
   



    }
}
