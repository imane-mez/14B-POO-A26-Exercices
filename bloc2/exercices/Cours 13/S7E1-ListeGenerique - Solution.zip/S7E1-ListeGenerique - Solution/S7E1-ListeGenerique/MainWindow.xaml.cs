﻿using S7E1_ListeGenerique.classes;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace S7E1_ListeGenerique
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Permet la gestion des films
        /// </summary>
        GestionFilms _gestionFilms;


        public MainWindow()
        {
            InitializeComponent();

            _gestionFilms = new GestionFilms();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
            AfficherListeFilms();
           

        }

        /// <summary>
        /// Initialise le contenu des champs du formulaire et initialise les boutons
        /// </summary>
        private void InitialiserFormulaire()
        {
            txtTitre.Clear();
            txtTitre.Focus();
            txtAnnee.Clear();
            btnSupprimer.IsEnabled = false;
            btnAjouter.IsEnabled = true;
            


        }

        private void btnNouveau_Click(object sender, RoutedEventArgs e)
        {

            InitialiserFormulaire();

        }

        /// <summary>
        /// Valider le contenu du formulaire
        /// </summary>
        /// <returns>Retourne true si le formulaire est valide, false sinon</returns>
        private bool ValiderFormulaire()
        {
            StringBuilder sb = new StringBuilder();


            if (string.IsNullOrEmpty(txtTitre.Text))
            {
                sb.AppendLine("- Vous devez inscire le titre du film.");
            }

            ushort annee = 0;

            if (!ushort.TryParse(txtAnnee.Text, out annee) || annee < Film.ANNEE_MIN || annee > DateTime.Now.Year)
            {
                sb.AppendLine($"- Vous devez inscrire une année entre {Film.ANNEE_MIN} et {DateTime.Now.Year}");

            }

            if (sb.Length > 0)
            {
                MessageBox.Show(sb.ToString(), "Validation du formulaire");
                return false;
            }

         

            return true;

        }

        private void bntAjouter_Click(object sender, RoutedEventArgs e)
        {
            if (ValiderFormulaire())
            {
                Film nouveauFilm = new Film(Guid.NewGuid(), txtTitre.Text.Trim(), ushort.Parse(txtAnnee.Text));

                string message;

                if (_gestionFilms.AjouterFilm(nouveauFilm))
                {
                    message = "Le film a été ajouté avec succès!";
                    AfficherListeFilms();
                    InitialiserFormulaire();
                }
                else
                {
                    message = "Il existe déjà un film ayant le même titre et la même anneé.";
                }

                MessageBox.Show(message, "Ajout d'un film");

            }
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            if (lstFilms.SelectedItem != null)
            {
                Film film = lstFilms.SelectedItem as Film;

                string message;

                if (_gestionFilms.SupprimerFilm(film))
                {
                    message = "Le film a été supprimé avec succès!";
                    AfficherListeFilms();


                }
                else
                {
                    message = "Impossible de supprimer ce film. Celui-ci n'existe pas dans la liste.";
                }

                AfficherListeFilms();
                InitialiserFormulaire();
                MessageBox.Show(message, "Suppression d'un film");
            }
        }

        private void lstFilms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstFilms.SelectedItem != null)
            {
                Film film = lstFilms.SelectedItem as Film;

                txtTitre.Text = film.Titre;
                txtAnnee.Text = film.Annee.ToString();

                btnSupprimer.IsEnabled = true;
                btnAjouter.IsEnabled = false;
            }
        }

        /// <summary>
        /// Permet l'affichage de la liste des films
        /// </summary>
        private void AfficherListeFilms()
        {
            lstFilms.Items.Clear();

            foreach (Film film in _gestionFilms.Films)
            {
                lstFilms.Items.Add(film);
            }
            

        }

        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

   
    }
}