﻿namespace S7E1_ListeGenerique.classes
{

    public class Film
    {
        /// <summary>
        /// Année minimale
        /// </summary>
        public const ushort ANNEE_MIN = 1500;
        public const string TITRE_DEFAUT = "Aucune titre";

        private Guid _id;
        private string _titre;
        private ushort _annee;

       
        /// <summary>
        /// Obtient ou définit l'identifiant unique d'un film
        /// </summary>
        public Guid Id
        {
            get { return _id; }
            set { _id = value; }
        }
        

        /// <summary>
        /// Obtient ou définit le titre
        /// </summary>
        public string Titre
        {
            get { return _titre; }
            set {
                if (string.IsNullOrWhiteSpace(value))
                    value = TITRE_DEFAUT;
                _titre = value.Trim(); 
            }
        }

        /// <summary>
        /// Obtient ou définit l'année de sortie du film.
        /// </summary>
        public ushort Annee
        {
            get { return _annee; }
            set {
                if (value < ANNEE_MIN || value > DateTime.Now.Year)
                    value = ANNEE_MIN;

                _annee = value;}
        }


        /// <summary>
        /// Constructeur paramétré acceptant le titre et l'année du film.
        /// </summary>
        /// <param name="titre">Titre du film.</param>
        /// <param name="annee">Année de sortie du film.</param>
        public Film(Guid id, string titre, ushort annee)
        {
            Id = id;
            Titre = titre;
            Annee = annee;
        }

     
        /// <summary>
        /// Permet d'obtenir une représentation du film.
        /// </summary>
        /// <returns>Un représentation du film sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return $"{Titre} ({Annee})";
        }

       
    }

}
