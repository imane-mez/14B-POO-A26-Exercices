﻿using System;
//using System.Collections.Generic;
using System.Text;

namespace S7E1_ListeGenerique.classes
{
    class GestionFilms
    {

   
        private List<Film> _films;
       

        /// <summary>
        /// Obtient ou définit la liste des films
        /// </summary>
        public List<Film> Films
        {
            get { return _films; }
            private set { _films = value; }
        }
     

     
        public GestionFilms()
        {
            Films = new List<Film>();
        }
       

       
        /// <summary>
        /// Permet de vérifier si un film existe déjà dans la liste.
        /// </summary>
        /// <param name="pFlim">Film recherché dans la liste</param>
        /// <returns>Si le film existe alors on retourne le film trouvé dans la liste. Sinon, on retourn null.</returns>
        private Film RechercherFilm(Film pFlim)
        {
            foreach (Film film in Films)
            {
               
                if (pFlim.Titre.ToLower().Trim() == film.Titre.ToLower().Trim() && pFlim.Annee == film.Annee)
                    return film;
            }

            return null;
        }

        /// <summary>
        /// Permet l'ajout d'un film à la la liste de film.
        /// </summary>
        /// <param name="pFilm">Fim à ajouter</param>
        /// <returns>Vrai si le film a été ajouté. Faux sinon.</returns>
        /// <remarks>Le film est ajouté seulement s'il n'existe pas de film identiques dans la liste.</remarks>
        public bool AjouterFilm(Film pFilm)
        {
            if(pFilm != null)
            {
                //if (RechercherFilm(pFilm) == null)
                if(!Films.Contains(pFilm))
                {
                    Films.Add(pFilm);
                    return true;
                }
            }
         

            return false;

        }

        /// <summary>
        /// Permet de supprimer un film de la liste
        /// </summary>
        /// <param name="film">Film à supprimer</param>
        /// <returns>Vrai si le film a été supprimé. Faux sinon.</returns>
        public bool SupprimerFilm(Film pFilm)
        {

            //return Films.Remove(pFilm);

            //ou

            Film film = RechercherFilm(pFilm);

            if (film != null)
            {
                return Films.Remove(film);
            }


            return false;
        }
       









    }
}
