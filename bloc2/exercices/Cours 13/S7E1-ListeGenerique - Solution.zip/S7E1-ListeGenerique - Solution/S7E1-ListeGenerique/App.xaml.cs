﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace S7E1_ListeGenerique
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
