﻿
using DemoValidationFormulaire.Enums;
using System;

namespace DemoValidationFormulaire.classes

{
    /// <summary>
    /// Représente un employé d'une compagnie.
    /// </summary>
    public class Employe
    {

       

      
        /// <summary>
        /// Âge de l'employé.
        /// </summary>
        public byte _age;


        /// <summary>
        /// Nom famille de l'employé.
        /// </summary>
        public string _nom;

        /// <summary>
        /// Prénom de l'employé.
        /// </summary>
        public string _prenom;

        /// <summary>
        /// Taux horaire de l'employé.
        /// </summary>
        /// <remarks>Ne peut pas être négatif.</remarks>
        public decimal _tauxHoraire;

  
        /// <summary>
        /// Type d'emploi occupé par l'employé
        /// </summary>
        private TypeEmploi _typeEmploi;

        

       
        /// <summary>
        /// Âge de l'employé.
        /// </summary>
        public byte Age
        {
            get { return _age; }
            set { _age = value; }
        }

        /// <summary>
        /// Nom famille de l'employé.
        /// </summary>
        public string Nom
        {
            get { return _nom; }
            set { 
                _nom = value; 
            }
        }

        /// <summary>
        /// Prénom de l'employé.
        /// </summary>
        public string Prenom
        {
            get { return _prenom; }
            set { _prenom = value; }
        }


       
        /// <summary>
        /// Taux horaire de l'employé.
        /// </summary>
        /// <remarks>Ne peut pas être négatif.</remarks>
        public decimal TauxHoraire
        {
            get { return _tauxHoraire; }
            set { _tauxHoraire = value; }
        }

        /// <summary>
        /// Type d'emploi occupé par l'employé
        /// </summary>
        public TypeEmploi TypeEmploi
        {
            get { return _typeEmploi; }
            set { _typeEmploi = value; }
        }

       

       
        /// <summary>
        /// Permet de construire un nouvel employé
        /// </summary>
        /// <param name="nom">Nom de famille de l'employé</param>
        /// <param name="prenom">Prénom de l'employé</param>
        /// <param name="age">Âge de l'employé</param>
        /// <param name="sexe">Sexe de l'employé</param>
        /// <param name="tauxHoraire"></param>
        public Employe(string nom, string prenom, byte age, decimal tauxHoraire, TypeEmploi typeEmploi)
        {
            Nom = nom;
            Prenom = prenom;
            Age = age;
            TauxHoraire = tauxHoraire;
            TypeEmploi = typeEmploi;
        }
        










    }
}
