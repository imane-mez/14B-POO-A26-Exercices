﻿using DemoValidationFormulaire.classes;
using DemoValidationFormulaire.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoValidationFormulaire
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        #region CONSTANTES

        #endregion

        #region ATTRIBUTS

       

        #endregion

        #region PROPRIÉTÉS ET INDEXEURS

        #endregion

        #region CONSTRUCTEURS
        public MainWindow()
        {
            InitializeComponent();

           
        }
        #endregion

        #region MÉTHODES

       

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

       
        

        #endregion

       
    }
}
