﻿

using DemoValidationFormulaire.Enums;

namespace DemoValidationFormulaire.classes
{
    /// <summary>
    /// Classe permettant de faire la gestion des employés
    /// </summary>
    public class GestionEmployes
    {

        #region CONSTANTES ET ATTRIBUTS STATIQUES
        //Nb. maximal d'employés
        public byte NB_EMPLOYES = 5;

        #endregion

        #region ATTRIBUTS

        //Vecteur d'employés
        private Employe[] _employes;


        #endregion

        #region PROPRIÉTÉS
        /// <summary>
        /// Obtient ou défini la liste des employés
        /// </summary>
        public Employe[] Employes
        {
            get { return _employes; }
            set { _employes = value; }
        }

        #endregion



        #region CONSTRUCTEURS

        /// <summary>
        /// Permet de construire un nouvel objet permettant la gestion d'employés
        /// </summary>
        public GestionEmployes()
        {
            Employes = ChargerEmployes();
        }

        #endregion

        #region MÉTHODES

        /// <summary>
        /// Cette méthode simule le chargement d'une liste d'employés contenue dans un fichier
        /// </summary>
        private Employe[] ChargerEmployes()
        {
            Employe[] employes = new Employe[5];

            employes[0] = new Employe("Vézina", "Martin", 44, 50m, TypeEmploi.Analyste);
            employes[1] = new Employe("Légaré", "Vincent", 40, 100m, TypeEmploi.Directeur);
            employes[2] = new Employe("Tremblay", "Marie", 35, 60m, TypeEmploi.ResponsableProjet);
            employes[3] = new Employe("Filiatreault", "Karine", 25, 45m, TypeEmploi.Technicien);
            employes[4] = new Employe("Mitnick", "Kevin", 55, 55, TypeEmploi.Architecte);

            return employes;

        }

       


        #endregion









    }
}
