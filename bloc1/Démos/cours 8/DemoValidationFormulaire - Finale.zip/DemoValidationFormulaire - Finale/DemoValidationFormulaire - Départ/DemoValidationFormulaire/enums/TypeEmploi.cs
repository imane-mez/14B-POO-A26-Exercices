﻿

using System.ComponentModel;

namespace DemoValidationFormulaire.Enums
{
    public enum TypeEmploi
    {
        Technicien,
        Analyste,
        Architecte,
        [Description("Resp. de projet")]
        ResponsableProjet,
        Directeur
    }
}
