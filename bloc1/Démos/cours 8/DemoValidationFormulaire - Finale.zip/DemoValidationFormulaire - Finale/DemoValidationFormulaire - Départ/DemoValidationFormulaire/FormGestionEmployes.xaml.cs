﻿using DemoValidationFormulaire.classes;
using DemoValidationFormulaire.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DemoValidationFormulaire
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        #region CONSTANTES

        #endregion

        #region ATTRIBUTS
        GestionEmployes _gestionEmploye;


        #endregion

        #region PROPRIÉTÉS ET INDEXEURS

        #endregion

        #region CONSTRUCTEURS
        public MainWindow()
        {
            InitializeComponent();
            _gestionEmploye = new GestionEmployes();
           
        }
        #endregion

        #region MÉTHODES   

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InitialiserFormulaire();
            
        }

       
        private void InitialiserFormulaire()
        {
            txtNom.Clear();
            txtPrenom.Clear();
            txtAge.Clear();
            txtTauxHoraire.Clear();

            InitListeEmployes();
            InitTypesEmplois();
        }

        private void InitListeEmployes()
        {
            lstEmployes.Items.Clear();
            for(int i=0; i < _gestionEmploye.Employes.Length; i++)
            {
                lstEmployes.Items.Add(_gestionEmploye.Employes[i]);
            }

        }

        private void InitTypesEmplois()
        {
            string[] tabTypesEmplois = UtilEnum.GetAllDescriptions<TypeEmploi>() ;
            for (int i = 0; i < tabTypesEmplois.Length; i++)
            {
                cboTypesEmplois.Items.Add(tabTypesEmplois[i]);
            }

        }

        #endregion

        private void lstEmployes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstEmployes.SelectedItem != null)
            {
                Employe employeSelect = (Employe)lstEmployes.SelectedItem;
                AfficherEmploye(employeSelect);
            }
                
        }

        private void AfficherEmploye(Employe employe)
        {        
            txtNom.Text = employe.Nom;
            txtPrenom.Text = employe.Prenom;
            txtAge.Text = employe.Age.ToString();
            txtTauxHoraire.Text = string.Format($"{employe.TauxHoraire:n2}");
            cboTypesEmplois.SelectedItem = UtilEnum.GetDescription(employe.TypeEmploi);
        }
        private void btnEnregistrer_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmployes.SelectedItem != null)
            {
                MessageBoxResult resultat = MessageBox.Show("Êtes vous certain de vouloir modifier les données ?",
                "Confirmation d'enregistrement",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question,
                MessageBoxResult.No);

                if (resultat == MessageBoxResult.Yes && ValiderDonnees())
                {
                    Employe employeSelect = (Employe)lstEmployes.SelectedItem;

                    employeSelect.Nom = txtNom.Text.Trim();
                    employeSelect.Prenom = txtPrenom.Text.Trim();
                    employeSelect.Age = byte.Parse(txtAge.Text);
                    employeSelect.TauxHoraire = decimal.Parse(txtTauxHoraire.Text);
                    employeSelect.TypeEmploi = (TypeEmploi)cboTypesEmplois.SelectedIndex;

                    InitListeEmployes();

                    MessageBox.Show("Données enregistrées avec succès",
                            "Confirmation d'enregistrement",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information);


                }
            }


            
        }

        private bool ValiderDonnees()
        {

            string messageErreur = "";

            if (string.IsNullOrWhiteSpace(txtNom.Text))
            {
                messageErreur += "- Le nom ne doit pas être vide.\n";
            }
            if (string.IsNullOrWhiteSpace(txtPrenom.Text) || txtPrenom.Text.Length < 3)
            {
                messageErreur += "- Le prénom doit compter au moins 3 caractères.\n";
            }

            byte age = 0;
            if ( !byte.TryParse(txtAge.Text, out age) || age < Employe.AGE_MIN)
            {
                messageErreur += $"- L'age doit etre numérique et supérieur à  {Employe.AGE_MIN}";
            }

            decimal tauxH = 0;
            if (!decimal.TryParse(txtTauxHoraire.Text, out tauxH) || tauxH < Employe.TAUX_MIN )
            {
                messageErreur += $"- Le taux horaire doit être numérique et supérieur à  {Employe.TAUX_MIN}";
            }


            if (messageErreur != "")
            {
                MessageBox.Show(messageErreur,
                        "Confirmation d'enregistrement",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information);
                return false;
            }

            return true;
        }

        private void btnAnnuler_Click(object sender, RoutedEventArgs e)
        {
            if (lstEmployes.SelectedItem != null)
            {
                Employe employeSelect = (Employe)lstEmployes.SelectedItem;
                AfficherEmploye(employeSelect);
            }
        }

        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
