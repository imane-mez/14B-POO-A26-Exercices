﻿


namespace S4E1_ExerciceValidation.classes
{
    /// <summary>
    /// Classe représentant un film.
    /// </summary>
    public class Film
    {
        #region ATTRIBUTS

        
        /// <summary>
        /// Titre du film.
        /// </summary>
        private string _titre;

        /// <summary>
        /// Année de sortie du film.
        /// </summary>
        private ushort _annee;

        #endregion

        #region PROPRIÉTÉS ET INDEXEURS


        /// <summary>
        /// Obtient le code du film
        /// </summary>
        public string Code
        {
            get { return Titre.ToUpper().Substring(0,3) + Annee.ToString(); }
           
        }

        /// <summary>
        /// Titre du film.
        /// </summary>
        public string Titre
        {
            get { return _titre; }
            private set { _titre = value.Trim(); }
        }

        /// <summary>
        /// Année de sortie du film.
        /// </summary>
        public ushort Annee
        {
            get { return _annee; }
            private set { _annee = value; }
        }

        #endregion

        #region CONSTRUCTEURS

        /// <summary>
        /// Constructeur paramétré acceptant le titre et l'année du film.
        /// </summary>
        /// <param name="titre">Titre du film.</param>
        /// <param name="annee">Année de sortie du film.</param>
        public Film(string titre, ushort annee)
        {
            Titre = titre;
            Annee = annee;
        }

        #endregion

        #region MÉTHODES

        // ========
        // Méthodes
        // ========
        //todo : Compléter la méthode 
        /// <summary>
        /// Permet d'obtenir une représentation du film.
        /// </summary>
        /// <returns>Un représentation du film sous forme de chaîne de caractères.</returns>
        public override string ToString()
        {
            return $"{Titre} ({Annee})";
        }

        #endregion
    }
}