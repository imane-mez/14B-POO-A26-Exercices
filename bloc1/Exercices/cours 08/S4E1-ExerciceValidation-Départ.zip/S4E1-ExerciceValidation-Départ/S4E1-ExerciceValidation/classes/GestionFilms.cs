﻿using System;
using System.Collections.Generic;

namespace S4E1_ExerciceValidation.classes
{
    class GestionFilms
    {

        #region CONSTANTES

        #endregion

        #region ATTRIBUTS
        //Liste des films
        private Film[] _films;
        #endregion

        #region PROPRIÉTÉS ET INDEXEURS
        /// <summary>
        /// Obtient ou définit la liste des films
        /// </summary>
        public Film[] Films
        {
            get { return _films; }
            set { _films = value; }
        }

        #endregion

        #region CONSTRUCTEURS
        /// <summary>
        /// Constructeur permettant d'initialiser une liste de films vide.
        /// </summary>
        public GestionFilms()
        {
            Films = new Film[0];
        }
        #endregion

        #region MÉTHODES

        #endregion

        /// <summary>
        /// Méthode permettant de vérifier qu'un film n'existe pas déjà dans la liste.
        /// </summary>
        /// <param name="pFlim"></param>
        /// <returns></returns>
        public bool Existe(Film pFlim)
        {
            //todo : compléter la méthode Existe
            throw new NotImplementedException();
        }

        /// <summary>
        /// Permet l'ajout d'un nouveau film à la fin du vecteur contenant les films
        /// </summary>
        /// <param name="pFilm">Nouveau Film a ajouter un vecteur</param>
        /// <returns>True si l'ajout a fonctionné, false sinon</returns>
        public bool AjouterFilm(Film pFilm)          
        {
            //todo : compléter la méthode AjouterFilm
            throw new NotImplementedException();
       
                
        }

     

    }
}
