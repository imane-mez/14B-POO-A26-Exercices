﻿

namespace S2E2_CreaturesMythiques
{
    public enum CreatureType
    {
        Elfe,
        Gobelin,
        Zombie
    }
}
