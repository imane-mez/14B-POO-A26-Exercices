﻿using System;
using System.Collections.Generic;
using System.Text;

namespace S2E2_CreaturesMythiques
{
    public class Creature
    {
        

        /// <summary>
        /// Type de créature par défaut; à utiliser si non spécifié lors de la construction de l'objet.
        /// </summary>
        public const CreatureType TYPE_CREATURE_DEFAUT = CreatureType.Elfe;

        /// <summary>
        /// Nombre de points de vie initialement pour un elfe.
        /// </summary>
        public const byte NB_VIE_ELF = 12;

        /// <summary>
        /// Nombre de points de vie initialement pour un gobelin.
        /// </summary>
        public const byte NB_VIE_GOBLIN = 15;

        /// <summary>
        /// Nombre de points de vie initialement pour un zombie.
        /// </summary>
        public const byte NB_VIE_ZOMBIE = 8;

        /// <summary>
        /// Nombre de points d'armure initialement pour un elfe.
        /// </summary>
        public const byte NB_ARMURE_ELF = 8;

        /// <summary>
        /// Nombre de points d'armure initialement pour un gobelin.
        /// </summary>
        public const byte NB_ARMURE_GOBELIN = 5;

        /// <summary>
        /// Nombre de points d'armure initialement pour un zombie.
        /// </summary>
        public const byte NB_ARMURE_ZOMBIE = 7;

        /// <summary>
        /// Nombre de pièces d'or initialement pour toutes les créatures.
        /// </summary>
        public const ushort NB_PIECES_OR = 10;

        /// <summary>
        /// Nombre de pièce d'or maximal pour toute les créatures.
        /// </summary>
        public const ushort NB_PIECES_OR_MAX = 100;

       



        /// <summary>
        /// Type de créature.
        /// </summary>
        private CreatureType _type;

        /// <summary>
        /// Nombre de points de vie.
        /// </summary>
        private byte _vie;

        /// <summary>
        /// Nombre de points d'armure.
        /// </summary>
        private byte _armure;

        /// <summary>
        /// Nombre de pièces d'or.
        /// </summary>
        private ushort _bourse;

      

       

        // Propriétés en lecture publiques et propriétés en écriture privées.

        /// <summary>
        /// Type de créature.
        /// </summary>
        public CreatureType Type
        {
            get { return _type; }
            private set { _type = value; } // Set privé, car le type d'une créature ne peut pas changé après sa création.
        }

        /// <summary>
        /// Nombre de points de vie.
        /// </summary>
        public byte Vie
        {
            get { return _vie; }
            set { _vie = value; }
        }

        /// <summary>
        /// Nombre de points d'armure.
        /// </summary>
        public byte Armure
        {
            get { return _armure; }
            set { _armure = value; }
        }

        /// <summary>
        /// Nombre de pièces d'or.
        /// </summary>
        public ushort Bourse
        {
            get { return _bourse; }
             set
            {
                //On empêche que la bourse contienne plus de pièces d'or que le maximum
                _bourse = value > NB_PIECES_OR_MAX ? NB_PIECES_OR_MAX : value;

          
            }
        }

    

    

        /// <summary>
        /// Constructeur pour une créature d'un certain type.
        /// </summary>
        /// <param name="type">Type de créature</param>
        public Creature(CreatureType type)
        {
            // Conservation du type de créature.
            Type = type;

            // Initialisation de la vie et de l'armure en fonction du type de créature.
            switch (Type)
            {
                case CreatureType.Elfe:
                    Vie = NB_VIE_ELF;
                    Armure = Creature.NB_ARMURE_ELF;
                    break;
                case CreatureType.Gobelin:
                    Vie = Creature.NB_VIE_GOBLIN;
                    Armure = Creature.NB_ARMURE_GOBELIN;
                    break;
                case CreatureType.Zombie:
                    Vie = Creature.NB_VIE_ZOMBIE;
                    Armure = Creature.NB_ARMURE_GOBELIN;
                    break;
            }

            // Toutes les créatures ont 10 pièces d'or initialement.
            Bourse = Creature.NB_PIECES_OR;
        }

        /// <summary>
        /// Constructeur sans paramètre; crée un Elfe par défaut.
        /// </summary>
        public Creature() : this(Creature.TYPE_CREATURE_DEFAUT)
        {
            // Appel l'autre constructeur qui est paramétré.
            // Dans le cas  présent, il n'y a pas d'autre code ici mais c'est bien sûr possible.
        }



       

        /// <summary>
        /// Permet d'attaquer la créature.
        /// </summary>
        /// <param name="forceAttaque">Force de l'attaque</param>
        public void SeFaireAttaquer(byte forceAttaque)
        {
            // Calcul du nombre de dommages à infliger à la créature (pas négatif).
            short nbDommages = (short)Math.Max(0, forceAttaque - Armure);

            // Est-ce qu'il y a des dommages ?
            if (nbDommages > 0)
            {
                // On réduit la vie du nombre de dommage à infliger.
                short nouvelleVie = (short)( Vie - nbDommages);

                Vie = (nouvelleVie <= 0) ? (byte)0 : (byte)nouvelleVie;
               
            }
        }

        /// <summary>
        /// Permet de voler la créature.
        /// </summary>
        /// <returns>Le nombre de pièces d'or volées.</returns>
        public ushort SeFaireVoler()
        {
            
            ushort butin = _bourse;
            Bourse = 0;
            return butin;
           
        }

        /// <summary>
        /// Indique si une créature est vivante.
        /// </summary>
        /// <returns>true si la créature est vivante et false, autrement.</returns>
        public bool EstVivante()
        {
            return _vie > 0;
        }

        /// <summary>
        /// Indique si une créature est morte.
        /// </summary>
        /// <returns>true si la créature est morte et false, autrement.</returns>
        public bool EstMorte()
        {
            // La créature est morte si elle n'est pas vivante.
            return !EstVivante();
        }

      
  
    }
}
