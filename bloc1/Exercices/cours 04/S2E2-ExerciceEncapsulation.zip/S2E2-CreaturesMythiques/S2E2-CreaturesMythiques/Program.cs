﻿using S2E2_CreaturesMythiques;
using System;
using System.Runtime.InteropServices;

namespace S2E2_CreaturesMythiques
{
    class Program
    {
        public const int ATTAQUE_MIN = 0;
        public const int ATTAQUE_MAX = 16;
        private static Random aleatoire = new Random();
        static void Main(string[] args)
        {
            Console.WriteLine("==================");
            Console.WriteLine("Créature Mythiques");
            Console.WriteLine("==================");

            Creature joueur = ChoisirCreature();
            AfficherCreature(joueur);


            Creature mechant = ChoisirCreature();
            AfficherCreature(mechant);


            bool tourJoueur1 = Convert.ToBoolean(aleatoire.Next(0, 2));
            byte nbPointsAttaque;

            do
            {
                //Console.Clear();

                nbPointsAttaque = (byte)aleatoire.Next(ATTAQUE_MIN, ATTAQUE_MAX);

                if (!tourJoueur1)
                {
                    joueur.SeFaireAttaquer(nbPointsAttaque);
                    Console.WriteLine($"Vous vous faites attaquer par le {mechant.Type} de {nbPointsAttaque} pts.");
                }
                else
                {
                    mechant.SeFaireAttaquer(nbPointsAttaque);
                    Console.WriteLine($"Vous attaquer le {mechant.Type} de {nbPointsAttaque} pts.");
                }

                tourJoueur1 = !tourJoueur1;

                Console.WriteLine("\n========================");
                Console.WriteLine("Résultat de l'attaque :\n");

                AfficherCreature(joueur);

                AfficherCreature(mechant);
                Console.WriteLine("\n========================");

                // Pause : Permet à utilisateur de voir le résultat de l'opération.
                Console.WriteLine("\nAppuyez sur une touche continuer le combat.");
                Console.ReadKey();



            } while (joueur.EstVivante() && mechant.EstVivante());


            ushort piecesVolees = 0;

            if (joueur.EstVivante())
            {
                Console.WriteLine("\nVous avez gagné le combat!");

                joueur.Bourse += mechant.SeFaireVoler();

                Console.WriteLine($"\nVous avez réussi à voler {piecesVolees} pièces d'or au {mechant.Type}");

                AfficherCreature(joueur);
            }
            else
            {
                Console.WriteLine("Vous avez perdu le combat!\n");
            }


        }

        /// <summary>
        /// Permet à l'utilisateur de faire un choix dans le menu
        /// </summary>
        /// <returns>Le choix de l'utilisateur dans le menu.</returns>
        static char DemanderChoixCreature()
        {

            Console.WriteLine("======================================================");
            Console.WriteLine("Choix d'une créature");
            Console.WriteLine("======================================================");
            Console.WriteLine("1) Elf");
            Console.WriteLine("2) Goblin");
            Console.WriteLine("3) zombie");
            Console.WriteLine("======================================================");

            Console.Write("\nSaisir votre choix ? ");
            char choixMenu = Console.ReadKey().KeyChar;
            Console.WriteLine("\n");

            return choixMenu;
        }

        static Creature ChoisirCreature()
        {
            //Choix de l'utilisateur
            char choixCreature;

            //Création d'un créature par défaut
            Creature creature = new Creature();

            do
            {
                //Demande le choix à  l'utlisateur à parti du menu.
                choixCreature = DemanderChoixCreature();

                switch (choixCreature)
                {
                    case '1':
                        //Création d'un elf
                        creature = new Creature();
                        break;
                    case '2':
                        //Création d'un goblin
                        creature = new Creature(CreatureType.Gobelin);
                        break;
                    case '3':
                        //Créatoin d'un zombie
                        creature = new Creature(CreatureType.Zombie);
                        break;
                    default:
                        Console.WriteLine("Erreur : Choix invalide");
                        //Modification de la valeur de choix pour le rendre invalide
                        choixCreature = '4';
                        break;

                }

            } while (choixCreature == '4');

            return creature;

        }

        /// <summary>
        /// Permet d'afficher une représentation de la créature.
        /// </summary>
        /// <returns>Un représentation de la créature sous forme de chaîne de caractères.</returns>
        static void AfficherCreature(Creature creature)
        {
            Console.WriteLine($"Créature de type  {creature.Type} (Vie = {creature.Vie}, Armure = {creature.Armure}, Bourse = {creature.Bourse})\n");
        }
    }
}
